﻿namespace Battleship
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.button143 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button139 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button136 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.button288 = new System.Windows.Forms.Button();
            this.button287 = new System.Windows.Forms.Button();
            this.button286 = new System.Windows.Forms.Button();
            this.button285 = new System.Windows.Forms.Button();
            this.button284 = new System.Windows.Forms.Button();
            this.button283 = new System.Windows.Forms.Button();
            this.button282 = new System.Windows.Forms.Button();
            this.button281 = new System.Windows.Forms.Button();
            this.button280 = new System.Windows.Forms.Button();
            this.button279 = new System.Windows.Forms.Button();
            this.button278 = new System.Windows.Forms.Button();
            this.button277 = new System.Windows.Forms.Button();
            this.button276 = new System.Windows.Forms.Button();
            this.button275 = new System.Windows.Forms.Button();
            this.button274 = new System.Windows.Forms.Button();
            this.button273 = new System.Windows.Forms.Button();
            this.button272 = new System.Windows.Forms.Button();
            this.button271 = new System.Windows.Forms.Button();
            this.button270 = new System.Windows.Forms.Button();
            this.button269 = new System.Windows.Forms.Button();
            this.button268 = new System.Windows.Forms.Button();
            this.button267 = new System.Windows.Forms.Button();
            this.button266 = new System.Windows.Forms.Button();
            this.button265 = new System.Windows.Forms.Button();
            this.button264 = new System.Windows.Forms.Button();
            this.button263 = new System.Windows.Forms.Button();
            this.button262 = new System.Windows.Forms.Button();
            this.button261 = new System.Windows.Forms.Button();
            this.button260 = new System.Windows.Forms.Button();
            this.button259 = new System.Windows.Forms.Button();
            this.button258 = new System.Windows.Forms.Button();
            this.button257 = new System.Windows.Forms.Button();
            this.button256 = new System.Windows.Forms.Button();
            this.button255 = new System.Windows.Forms.Button();
            this.button254 = new System.Windows.Forms.Button();
            this.button253 = new System.Windows.Forms.Button();
            this.button252 = new System.Windows.Forms.Button();
            this.button251 = new System.Windows.Forms.Button();
            this.button250 = new System.Windows.Forms.Button();
            this.button249 = new System.Windows.Forms.Button();
            this.button248 = new System.Windows.Forms.Button();
            this.button247 = new System.Windows.Forms.Button();
            this.button246 = new System.Windows.Forms.Button();
            this.button245 = new System.Windows.Forms.Button();
            this.button244 = new System.Windows.Forms.Button();
            this.button243 = new System.Windows.Forms.Button();
            this.button242 = new System.Windows.Forms.Button();
            this.button241 = new System.Windows.Forms.Button();
            this.button240 = new System.Windows.Forms.Button();
            this.button239 = new System.Windows.Forms.Button();
            this.button238 = new System.Windows.Forms.Button();
            this.button237 = new System.Windows.Forms.Button();
            this.button236 = new System.Windows.Forms.Button();
            this.button235 = new System.Windows.Forms.Button();
            this.button234 = new System.Windows.Forms.Button();
            this.button233 = new System.Windows.Forms.Button();
            this.button232 = new System.Windows.Forms.Button();
            this.button231 = new System.Windows.Forms.Button();
            this.button230 = new System.Windows.Forms.Button();
            this.button229 = new System.Windows.Forms.Button();
            this.button228 = new System.Windows.Forms.Button();
            this.button227 = new System.Windows.Forms.Button();
            this.button226 = new System.Windows.Forms.Button();
            this.button225 = new System.Windows.Forms.Button();
            this.button224 = new System.Windows.Forms.Button();
            this.button223 = new System.Windows.Forms.Button();
            this.button222 = new System.Windows.Forms.Button();
            this.button221 = new System.Windows.Forms.Button();
            this.button220 = new System.Windows.Forms.Button();
            this.button219 = new System.Windows.Forms.Button();
            this.button218 = new System.Windows.Forms.Button();
            this.button217 = new System.Windows.Forms.Button();
            this.button215 = new System.Windows.Forms.Button();
            this.button214 = new System.Windows.Forms.Button();
            this.button213 = new System.Windows.Forms.Button();
            this.button212 = new System.Windows.Forms.Button();
            this.button211 = new System.Windows.Forms.Button();
            this.button210 = new System.Windows.Forms.Button();
            this.button209 = new System.Windows.Forms.Button();
            this.button208 = new System.Windows.Forms.Button();
            this.button207 = new System.Windows.Forms.Button();
            this.button206 = new System.Windows.Forms.Button();
            this.button205 = new System.Windows.Forms.Button();
            this.button204 = new System.Windows.Forms.Button();
            this.button203 = new System.Windows.Forms.Button();
            this.button202 = new System.Windows.Forms.Button();
            this.button201 = new System.Windows.Forms.Button();
            this.button200 = new System.Windows.Forms.Button();
            this.button199 = new System.Windows.Forms.Button();
            this.button198 = new System.Windows.Forms.Button();
            this.button197 = new System.Windows.Forms.Button();
            this.button196 = new System.Windows.Forms.Button();
            this.button195 = new System.Windows.Forms.Button();
            this.button194 = new System.Windows.Forms.Button();
            this.button193 = new System.Windows.Forms.Button();
            this.button192 = new System.Windows.Forms.Button();
            this.button191 = new System.Windows.Forms.Button();
            this.button190 = new System.Windows.Forms.Button();
            this.button189 = new System.Windows.Forms.Button();
            this.button188 = new System.Windows.Forms.Button();
            this.button187 = new System.Windows.Forms.Button();
            this.button186 = new System.Windows.Forms.Button();
            this.button185 = new System.Windows.Forms.Button();
            this.button184 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.button182 = new System.Windows.Forms.Button();
            this.button181 = new System.Windows.Forms.Button();
            this.button180 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button178 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button175 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.button172 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.button170 = new System.Windows.Forms.Button();
            this.button169 = new System.Windows.Forms.Button();
            this.button168 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button166 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.button164 = new System.Windows.Forms.Button();
            this.button163 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.button160 = new System.Windows.Forms.Button();
            this.button159 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button157 = new System.Windows.Forms.Button();
            this.button156 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button154 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.button216 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button148 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.btnNewGame = new System.Windows.Forms.Button();
            this.rbVertical = new System.Windows.Forms.RadioButton();
            this.groupBoxPlayerAlignment = new System.Windows.Forms.GroupBox();
            this.rbHorizontal = new System.Windows.Forms.RadioButton();
            this.groupBoxPlayerShips = new System.Windows.Forms.GroupBox();
            this.rbSubmarine = new System.Windows.Forms.RadioButton();
            this.rbPTBoat = new System.Windows.Forms.RadioButton();
            this.rbCarrier = new System.Windows.Forms.RadioButton();
            this.rbBattleship = new System.Windows.Forms.RadioButton();
            this.rbCruiser = new System.Windows.Forms.RadioButton();
            this.btnReady = new System.Windows.Forms.Button();
            this.btnSurrender = new System.Windows.Forms.Button();
            this.lblTurnCounter = new System.Windows.Forms.Label();
            this.lblCounter = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.lblHumanCoordinates = new System.Windows.Forms.Label();
            this.lblCPUCoordinate = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.pbHeader = new System.Windows.Forms.PictureBox();
            this.pbCPUCarrier = new System.Windows.Forms.PictureBox();
            this.pbCPUBattleship = new System.Windows.Forms.PictureBox();
            this.pbCPUSub = new System.Windows.Forms.PictureBox();
            this.pbCPUCruiser = new System.Windows.Forms.PictureBox();
            this.pbCPUPtBoat = new System.Windows.Forms.PictureBox();
            this.pbHumanCarrier = new System.Windows.Forms.PictureBox();
            this.pbHumanBattleship = new System.Windows.Forms.PictureBox();
            this.pbHumanSub = new System.Windows.Forms.PictureBox();
            this.pbHumanCruiser = new System.Windows.Forms.PictureBox();
            this.pbHumanPTBoat = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBoxPlayerAlignment.SuspendLayout();
            this.groupBoxPlayerShips.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeader)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCPUCarrier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCPUBattleship)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCPUSub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCPUCruiser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCPUPtBoat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHumanCarrier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHumanBattleship)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHumanSub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHumanCruiser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHumanPTBoat)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 12;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel1.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button144, 11, 11);
            this.tableLayoutPanel1.Controls.Add(this.button143, 10, 11);
            this.tableLayoutPanel1.Controls.Add(this.button142, 9, 11);
            this.tableLayoutPanel1.Controls.Add(this.button141, 8, 11);
            this.tableLayoutPanel1.Controls.Add(this.button140, 7, 11);
            this.tableLayoutPanel1.Controls.Add(this.button139, 6, 11);
            this.tableLayoutPanel1.Controls.Add(this.button138, 5, 11);
            this.tableLayoutPanel1.Controls.Add(this.button137, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.button136, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.button135, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.button134, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.button133, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.button132, 11, 10);
            this.tableLayoutPanel1.Controls.Add(this.button131, 10, 10);
            this.tableLayoutPanel1.Controls.Add(this.button130, 9, 10);
            this.tableLayoutPanel1.Controls.Add(this.button129, 8, 10);
            this.tableLayoutPanel1.Controls.Add(this.button128, 7, 10);
            this.tableLayoutPanel1.Controls.Add(this.button127, 6, 10);
            this.tableLayoutPanel1.Controls.Add(this.button126, 5, 10);
            this.tableLayoutPanel1.Controls.Add(this.button125, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.button124, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.button123, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.button122, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.button121, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.button120, 11, 9);
            this.tableLayoutPanel1.Controls.Add(this.button119, 10, 9);
            this.tableLayoutPanel1.Controls.Add(this.button118, 9, 9);
            this.tableLayoutPanel1.Controls.Add(this.button117, 8, 9);
            this.tableLayoutPanel1.Controls.Add(this.button116, 7, 9);
            this.tableLayoutPanel1.Controls.Add(this.button115, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.button114, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.button113, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.button112, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.button111, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.button110, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.button109, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.button108, 11, 8);
            this.tableLayoutPanel1.Controls.Add(this.button107, 10, 8);
            this.tableLayoutPanel1.Controls.Add(this.button106, 9, 8);
            this.tableLayoutPanel1.Controls.Add(this.button105, 8, 8);
            this.tableLayoutPanel1.Controls.Add(this.button104, 7, 8);
            this.tableLayoutPanel1.Controls.Add(this.button103, 6, 8);
            this.tableLayoutPanel1.Controls.Add(this.button102, 5, 8);
            this.tableLayoutPanel1.Controls.Add(this.button101, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.button100, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.button99, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.button98, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.button97, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.button96, 11, 7);
            this.tableLayoutPanel1.Controls.Add(this.button95, 10, 7);
            this.tableLayoutPanel1.Controls.Add(this.button94, 9, 7);
            this.tableLayoutPanel1.Controls.Add(this.button93, 8, 7);
            this.tableLayoutPanel1.Controls.Add(this.button92, 7, 7);
            this.tableLayoutPanel1.Controls.Add(this.button91, 6, 7);
            this.tableLayoutPanel1.Controls.Add(this.button90, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.button89, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.button88, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.button87, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.button86, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.button85, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.button84, 11, 6);
            this.tableLayoutPanel1.Controls.Add(this.button83, 10, 6);
            this.tableLayoutPanel1.Controls.Add(this.button82, 9, 6);
            this.tableLayoutPanel1.Controls.Add(this.button81, 8, 6);
            this.tableLayoutPanel1.Controls.Add(this.button80, 7, 6);
            this.tableLayoutPanel1.Controls.Add(this.button79, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.button78, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.button77, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.button76, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.button75, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.button74, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.button73, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.button72, 11, 5);
            this.tableLayoutPanel1.Controls.Add(this.button71, 10, 5);
            this.tableLayoutPanel1.Controls.Add(this.button70, 9, 5);
            this.tableLayoutPanel1.Controls.Add(this.button69, 8, 5);
            this.tableLayoutPanel1.Controls.Add(this.button68, 7, 5);
            this.tableLayoutPanel1.Controls.Add(this.button67, 6, 5);
            this.tableLayoutPanel1.Controls.Add(this.button66, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.button65, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.button64, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.button63, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.button62, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.button61, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.button60, 11, 4);
            this.tableLayoutPanel1.Controls.Add(this.button59, 10, 4);
            this.tableLayoutPanel1.Controls.Add(this.button58, 9, 4);
            this.tableLayoutPanel1.Controls.Add(this.button57, 8, 4);
            this.tableLayoutPanel1.Controls.Add(this.button56, 7, 4);
            this.tableLayoutPanel1.Controls.Add(this.button55, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.button54, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.button53, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.button52, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.button51, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.button50, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.button49, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.button48, 11, 3);
            this.tableLayoutPanel1.Controls.Add(this.button47, 10, 3);
            this.tableLayoutPanel1.Controls.Add(this.button46, 9, 3);
            this.tableLayoutPanel1.Controls.Add(this.button45, 8, 3);
            this.tableLayoutPanel1.Controls.Add(this.button44, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.button43, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.button42, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.button41, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.button40, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.button39, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.button38, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.button37, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.button36, 11, 2);
            this.tableLayoutPanel1.Controls.Add(this.button35, 10, 2);
            this.tableLayoutPanel1.Controls.Add(this.button34, 9, 2);
            this.tableLayoutPanel1.Controls.Add(this.button33, 8, 2);
            this.tableLayoutPanel1.Controls.Add(this.button32, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.button31, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.button30, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.button29, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.button28, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.button27, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.button26, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button25, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.button24, 11, 1);
            this.tableLayoutPanel1.Controls.Add(this.button23, 10, 1);
            this.tableLayoutPanel1.Controls.Add(this.button22, 9, 1);
            this.tableLayoutPanel1.Controls.Add(this.button21, 8, 1);
            this.tableLayoutPanel1.Controls.Add(this.button20, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.button19, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.button18, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.button17, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.button16, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.button15, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.button14, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button13, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.button12, 11, 0);
            this.tableLayoutPanel1.Controls.Add(this.button11, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.button10, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.button9, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.button8, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.button7, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.button6, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.button5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.button4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.button3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.button2, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(68, 98);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 12;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(400, 400);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(2, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(30, 28);
            this.button1.TabIndex = 221;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button144
            // 
            this.button144.Location = new System.Drawing.Point(365, 365);
            this.button144.Margin = new System.Windows.Forms.Padding(1);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(30, 28);
            this.button144.TabIndex = 363;
            this.button144.UseVisualStyleBackColor = true;
            // 
            // button143
            // 
            this.button143.Location = new System.Drawing.Point(332, 365);
            this.button143.Margin = new System.Windows.Forms.Padding(1);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(30, 28);
            this.button143.TabIndex = 362;
            this.button143.UseVisualStyleBackColor = true;
            // 
            // button142
            // 
            this.button142.Location = new System.Drawing.Point(299, 365);
            this.button142.Margin = new System.Windows.Forms.Padding(1);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(30, 28);
            this.button142.TabIndex = 361;
            this.button142.UseVisualStyleBackColor = true;
            // 
            // button141
            // 
            this.button141.Location = new System.Drawing.Point(266, 365);
            this.button141.Margin = new System.Windows.Forms.Padding(1);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(30, 28);
            this.button141.TabIndex = 360;
            this.button141.UseVisualStyleBackColor = true;
            // 
            // button140
            // 
            this.button140.Location = new System.Drawing.Point(233, 365);
            this.button140.Margin = new System.Windows.Forms.Padding(1);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(30, 28);
            this.button140.TabIndex = 359;
            this.button140.UseVisualStyleBackColor = true;
            // 
            // button139
            // 
            this.button139.Location = new System.Drawing.Point(200, 365);
            this.button139.Margin = new System.Windows.Forms.Padding(1);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(30, 28);
            this.button139.TabIndex = 358;
            this.button139.UseVisualStyleBackColor = true;
            // 
            // button138
            // 
            this.button138.Location = new System.Drawing.Point(167, 365);
            this.button138.Margin = new System.Windows.Forms.Padding(1);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(30, 28);
            this.button138.TabIndex = 357;
            this.button138.UseVisualStyleBackColor = true;
            // 
            // button137
            // 
            this.button137.Location = new System.Drawing.Point(134, 365);
            this.button137.Margin = new System.Windows.Forms.Padding(1);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(30, 28);
            this.button137.TabIndex = 356;
            this.button137.UseVisualStyleBackColor = true;
            // 
            // button136
            // 
            this.button136.Location = new System.Drawing.Point(101, 365);
            this.button136.Margin = new System.Windows.Forms.Padding(1);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(30, 28);
            this.button136.TabIndex = 355;
            this.button136.UseVisualStyleBackColor = true;
            // 
            // button135
            // 
            this.button135.Location = new System.Drawing.Point(68, 365);
            this.button135.Margin = new System.Windows.Forms.Padding(1);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(30, 28);
            this.button135.TabIndex = 354;
            this.button135.UseVisualStyleBackColor = true;
            // 
            // button134
            // 
            this.button134.Location = new System.Drawing.Point(35, 365);
            this.button134.Margin = new System.Windows.Forms.Padding(1);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(30, 28);
            this.button134.TabIndex = 353;
            this.button134.UseVisualStyleBackColor = true;
            // 
            // button133
            // 
            this.button133.Location = new System.Drawing.Point(2, 365);
            this.button133.Margin = new System.Windows.Forms.Padding(1);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(30, 28);
            this.button133.TabIndex = 352;
            this.button133.UseVisualStyleBackColor = true;
            // 
            // button132
            // 
            this.button132.Location = new System.Drawing.Point(365, 332);
            this.button132.Margin = new System.Windows.Forms.Padding(1);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(30, 28);
            this.button132.TabIndex = 351;
            this.button132.UseVisualStyleBackColor = true;
            // 
            // button131
            // 
            this.button131.Location = new System.Drawing.Point(332, 332);
            this.button131.Margin = new System.Windows.Forms.Padding(1);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(30, 28);
            this.button131.TabIndex = 350;
            this.button131.UseVisualStyleBackColor = true;
            // 
            // button130
            // 
            this.button130.Location = new System.Drawing.Point(299, 332);
            this.button130.Margin = new System.Windows.Forms.Padding(1);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(30, 28);
            this.button130.TabIndex = 349;
            this.button130.UseVisualStyleBackColor = true;
            // 
            // button129
            // 
            this.button129.Location = new System.Drawing.Point(266, 332);
            this.button129.Margin = new System.Windows.Forms.Padding(1);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(30, 28);
            this.button129.TabIndex = 348;
            this.button129.UseVisualStyleBackColor = true;
            // 
            // button128
            // 
            this.button128.Location = new System.Drawing.Point(233, 332);
            this.button128.Margin = new System.Windows.Forms.Padding(1);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(30, 28);
            this.button128.TabIndex = 347;
            this.button128.UseVisualStyleBackColor = true;
            // 
            // button127
            // 
            this.button127.Location = new System.Drawing.Point(200, 332);
            this.button127.Margin = new System.Windows.Forms.Padding(1);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(30, 28);
            this.button127.TabIndex = 346;
            this.button127.UseVisualStyleBackColor = true;
            // 
            // button126
            // 
            this.button126.Location = new System.Drawing.Point(167, 332);
            this.button126.Margin = new System.Windows.Forms.Padding(1);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(30, 28);
            this.button126.TabIndex = 345;
            this.button126.UseVisualStyleBackColor = true;
            // 
            // button125
            // 
            this.button125.Location = new System.Drawing.Point(134, 332);
            this.button125.Margin = new System.Windows.Forms.Padding(1);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(30, 28);
            this.button125.TabIndex = 344;
            this.button125.UseVisualStyleBackColor = true;
            // 
            // button124
            // 
            this.button124.Location = new System.Drawing.Point(101, 332);
            this.button124.Margin = new System.Windows.Forms.Padding(1);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(30, 28);
            this.button124.TabIndex = 343;
            this.button124.UseVisualStyleBackColor = true;
            // 
            // button123
            // 
            this.button123.Location = new System.Drawing.Point(68, 332);
            this.button123.Margin = new System.Windows.Forms.Padding(1);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(30, 28);
            this.button123.TabIndex = 342;
            this.button123.UseVisualStyleBackColor = true;
            // 
            // button122
            // 
            this.button122.Location = new System.Drawing.Point(35, 332);
            this.button122.Margin = new System.Windows.Forms.Padding(1);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(30, 28);
            this.button122.TabIndex = 341;
            this.button122.UseVisualStyleBackColor = true;
            // 
            // button121
            // 
            this.button121.Location = new System.Drawing.Point(2, 332);
            this.button121.Margin = new System.Windows.Forms.Padding(1);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(30, 28);
            this.button121.TabIndex = 340;
            this.button121.UseVisualStyleBackColor = true;
            // 
            // button120
            // 
            this.button120.Location = new System.Drawing.Point(365, 299);
            this.button120.Margin = new System.Windows.Forms.Padding(1);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(30, 28);
            this.button120.TabIndex = 339;
            this.button120.UseVisualStyleBackColor = true;
            // 
            // button119
            // 
            this.button119.Location = new System.Drawing.Point(332, 299);
            this.button119.Margin = new System.Windows.Forms.Padding(1);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(30, 28);
            this.button119.TabIndex = 338;
            this.button119.UseVisualStyleBackColor = true;
            // 
            // button118
            // 
            this.button118.Location = new System.Drawing.Point(299, 299);
            this.button118.Margin = new System.Windows.Forms.Padding(1);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(30, 28);
            this.button118.TabIndex = 337;
            this.button118.UseVisualStyleBackColor = true;
            // 
            // button117
            // 
            this.button117.Location = new System.Drawing.Point(266, 299);
            this.button117.Margin = new System.Windows.Forms.Padding(1);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(30, 28);
            this.button117.TabIndex = 336;
            this.button117.UseVisualStyleBackColor = true;
            // 
            // button116
            // 
            this.button116.Location = new System.Drawing.Point(233, 299);
            this.button116.Margin = new System.Windows.Forms.Padding(1);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(30, 28);
            this.button116.TabIndex = 335;
            this.button116.UseVisualStyleBackColor = true;
            // 
            // button115
            // 
            this.button115.Location = new System.Drawing.Point(200, 299);
            this.button115.Margin = new System.Windows.Forms.Padding(1);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(30, 28);
            this.button115.TabIndex = 334;
            this.button115.UseVisualStyleBackColor = true;
            // 
            // button114
            // 
            this.button114.Location = new System.Drawing.Point(167, 299);
            this.button114.Margin = new System.Windows.Forms.Padding(1);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(30, 28);
            this.button114.TabIndex = 333;
            this.button114.UseVisualStyleBackColor = true;
            // 
            // button113
            // 
            this.button113.Location = new System.Drawing.Point(134, 299);
            this.button113.Margin = new System.Windows.Forms.Padding(1);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(30, 28);
            this.button113.TabIndex = 332;
            this.button113.UseVisualStyleBackColor = true;
            // 
            // button112
            // 
            this.button112.Location = new System.Drawing.Point(101, 299);
            this.button112.Margin = new System.Windows.Forms.Padding(1);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(30, 28);
            this.button112.TabIndex = 331;
            this.button112.UseVisualStyleBackColor = true;
            // 
            // button111
            // 
            this.button111.Location = new System.Drawing.Point(68, 299);
            this.button111.Margin = new System.Windows.Forms.Padding(1);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(30, 28);
            this.button111.TabIndex = 330;
            this.button111.UseVisualStyleBackColor = true;
            // 
            // button110
            // 
            this.button110.Location = new System.Drawing.Point(35, 299);
            this.button110.Margin = new System.Windows.Forms.Padding(1);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(30, 28);
            this.button110.TabIndex = 329;
            this.button110.UseVisualStyleBackColor = true;
            // 
            // button109
            // 
            this.button109.Location = new System.Drawing.Point(2, 299);
            this.button109.Margin = new System.Windows.Forms.Padding(1);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(30, 28);
            this.button109.TabIndex = 328;
            this.button109.UseVisualStyleBackColor = true;
            // 
            // button108
            // 
            this.button108.Location = new System.Drawing.Point(365, 266);
            this.button108.Margin = new System.Windows.Forms.Padding(1);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(30, 28);
            this.button108.TabIndex = 327;
            this.button108.UseVisualStyleBackColor = true;
            // 
            // button107
            // 
            this.button107.Location = new System.Drawing.Point(332, 266);
            this.button107.Margin = new System.Windows.Forms.Padding(1);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(30, 28);
            this.button107.TabIndex = 326;
            this.button107.UseVisualStyleBackColor = true;
            // 
            // button106
            // 
            this.button106.Location = new System.Drawing.Point(299, 266);
            this.button106.Margin = new System.Windows.Forms.Padding(1);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(30, 28);
            this.button106.TabIndex = 325;
            this.button106.UseVisualStyleBackColor = true;
            // 
            // button105
            // 
            this.button105.Location = new System.Drawing.Point(266, 266);
            this.button105.Margin = new System.Windows.Forms.Padding(1);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(30, 28);
            this.button105.TabIndex = 324;
            this.button105.UseVisualStyleBackColor = true;
            // 
            // button104
            // 
            this.button104.Location = new System.Drawing.Point(233, 266);
            this.button104.Margin = new System.Windows.Forms.Padding(1);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(30, 28);
            this.button104.TabIndex = 323;
            this.button104.UseVisualStyleBackColor = true;
            // 
            // button103
            // 
            this.button103.Location = new System.Drawing.Point(200, 266);
            this.button103.Margin = new System.Windows.Forms.Padding(1);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(30, 28);
            this.button103.TabIndex = 322;
            this.button103.UseVisualStyleBackColor = true;
            // 
            // button102
            // 
            this.button102.Location = new System.Drawing.Point(167, 266);
            this.button102.Margin = new System.Windows.Forms.Padding(1);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(30, 28);
            this.button102.TabIndex = 321;
            this.button102.UseVisualStyleBackColor = true;
            // 
            // button101
            // 
            this.button101.Location = new System.Drawing.Point(134, 266);
            this.button101.Margin = new System.Windows.Forms.Padding(1);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(30, 28);
            this.button101.TabIndex = 320;
            this.button101.UseVisualStyleBackColor = true;
            // 
            // button100
            // 
            this.button100.Location = new System.Drawing.Point(101, 266);
            this.button100.Margin = new System.Windows.Forms.Padding(1);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(30, 28);
            this.button100.TabIndex = 319;
            this.button100.UseVisualStyleBackColor = true;
            // 
            // button99
            // 
            this.button99.Location = new System.Drawing.Point(68, 266);
            this.button99.Margin = new System.Windows.Forms.Padding(1);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(30, 28);
            this.button99.TabIndex = 318;
            this.button99.UseVisualStyleBackColor = true;
            // 
            // button98
            // 
            this.button98.Location = new System.Drawing.Point(35, 266);
            this.button98.Margin = new System.Windows.Forms.Padding(1);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(30, 28);
            this.button98.TabIndex = 317;
            this.button98.UseVisualStyleBackColor = true;
            // 
            // button97
            // 
            this.button97.Location = new System.Drawing.Point(2, 266);
            this.button97.Margin = new System.Windows.Forms.Padding(1);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(30, 28);
            this.button97.TabIndex = 316;
            this.button97.UseVisualStyleBackColor = true;
            // 
            // button96
            // 
            this.button96.Location = new System.Drawing.Point(365, 233);
            this.button96.Margin = new System.Windows.Forms.Padding(1);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(30, 28);
            this.button96.TabIndex = 315;
            this.button96.UseVisualStyleBackColor = true;
            // 
            // button95
            // 
            this.button95.Location = new System.Drawing.Point(332, 233);
            this.button95.Margin = new System.Windows.Forms.Padding(1);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(30, 28);
            this.button95.TabIndex = 314;
            this.button95.UseVisualStyleBackColor = true;
            // 
            // button94
            // 
            this.button94.Location = new System.Drawing.Point(299, 233);
            this.button94.Margin = new System.Windows.Forms.Padding(1);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(30, 28);
            this.button94.TabIndex = 313;
            this.button94.UseVisualStyleBackColor = true;
            // 
            // button93
            // 
            this.button93.Location = new System.Drawing.Point(266, 233);
            this.button93.Margin = new System.Windows.Forms.Padding(1);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(30, 28);
            this.button93.TabIndex = 312;
            this.button93.UseVisualStyleBackColor = true;
            // 
            // button92
            // 
            this.button92.Location = new System.Drawing.Point(233, 233);
            this.button92.Margin = new System.Windows.Forms.Padding(1);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(30, 28);
            this.button92.TabIndex = 311;
            this.button92.UseVisualStyleBackColor = true;
            // 
            // button91
            // 
            this.button91.Location = new System.Drawing.Point(200, 233);
            this.button91.Margin = new System.Windows.Forms.Padding(1);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(30, 28);
            this.button91.TabIndex = 310;
            this.button91.UseVisualStyleBackColor = true;
            // 
            // button90
            // 
            this.button90.Location = new System.Drawing.Point(167, 233);
            this.button90.Margin = new System.Windows.Forms.Padding(1);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(30, 28);
            this.button90.TabIndex = 309;
            this.button90.UseVisualStyleBackColor = true;
            // 
            // button89
            // 
            this.button89.Location = new System.Drawing.Point(134, 233);
            this.button89.Margin = new System.Windows.Forms.Padding(1);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(30, 28);
            this.button89.TabIndex = 308;
            this.button89.UseVisualStyleBackColor = true;
            // 
            // button88
            // 
            this.button88.Location = new System.Drawing.Point(101, 233);
            this.button88.Margin = new System.Windows.Forms.Padding(1);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(30, 28);
            this.button88.TabIndex = 307;
            this.button88.UseVisualStyleBackColor = true;
            // 
            // button87
            // 
            this.button87.Location = new System.Drawing.Point(68, 233);
            this.button87.Margin = new System.Windows.Forms.Padding(1);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(30, 28);
            this.button87.TabIndex = 306;
            this.button87.UseVisualStyleBackColor = true;
            // 
            // button86
            // 
            this.button86.Location = new System.Drawing.Point(35, 233);
            this.button86.Margin = new System.Windows.Forms.Padding(1);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(30, 28);
            this.button86.TabIndex = 305;
            this.button86.UseVisualStyleBackColor = true;
            // 
            // button85
            // 
            this.button85.Location = new System.Drawing.Point(2, 233);
            this.button85.Margin = new System.Windows.Forms.Padding(1);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(30, 28);
            this.button85.TabIndex = 304;
            this.button85.UseVisualStyleBackColor = true;
            // 
            // button84
            // 
            this.button84.Location = new System.Drawing.Point(365, 200);
            this.button84.Margin = new System.Windows.Forms.Padding(1);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(30, 28);
            this.button84.TabIndex = 303;
            this.button84.UseVisualStyleBackColor = true;
            // 
            // button83
            // 
            this.button83.Location = new System.Drawing.Point(332, 200);
            this.button83.Margin = new System.Windows.Forms.Padding(1);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(30, 28);
            this.button83.TabIndex = 302;
            this.button83.UseVisualStyleBackColor = true;
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(299, 200);
            this.button82.Margin = new System.Windows.Forms.Padding(1);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(30, 28);
            this.button82.TabIndex = 301;
            this.button82.UseVisualStyleBackColor = true;
            // 
            // button81
            // 
            this.button81.Location = new System.Drawing.Point(266, 200);
            this.button81.Margin = new System.Windows.Forms.Padding(1);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(30, 28);
            this.button81.TabIndex = 300;
            this.button81.UseVisualStyleBackColor = true;
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(233, 200);
            this.button80.Margin = new System.Windows.Forms.Padding(1);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(30, 28);
            this.button80.TabIndex = 299;
            this.button80.UseVisualStyleBackColor = true;
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(200, 200);
            this.button79.Margin = new System.Windows.Forms.Padding(1);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(30, 28);
            this.button79.TabIndex = 298;
            this.button79.UseVisualStyleBackColor = true;
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(167, 200);
            this.button78.Margin = new System.Windows.Forms.Padding(1);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(30, 28);
            this.button78.TabIndex = 297;
            this.button78.UseVisualStyleBackColor = true;
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(134, 200);
            this.button77.Margin = new System.Windows.Forms.Padding(1);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(30, 28);
            this.button77.TabIndex = 296;
            this.button77.UseVisualStyleBackColor = true;
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(101, 200);
            this.button76.Margin = new System.Windows.Forms.Padding(1);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(30, 28);
            this.button76.TabIndex = 295;
            this.button76.UseVisualStyleBackColor = true;
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(68, 200);
            this.button75.Margin = new System.Windows.Forms.Padding(1);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(30, 28);
            this.button75.TabIndex = 294;
            this.button75.UseVisualStyleBackColor = true;
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(35, 200);
            this.button74.Margin = new System.Windows.Forms.Padding(1);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(30, 28);
            this.button74.TabIndex = 293;
            this.button74.UseVisualStyleBackColor = true;
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(2, 200);
            this.button73.Margin = new System.Windows.Forms.Padding(1);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(30, 28);
            this.button73.TabIndex = 292;
            this.button73.UseVisualStyleBackColor = true;
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(365, 167);
            this.button72.Margin = new System.Windows.Forms.Padding(1);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(30, 28);
            this.button72.TabIndex = 291;
            this.button72.UseVisualStyleBackColor = true;
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(332, 167);
            this.button71.Margin = new System.Windows.Forms.Padding(1);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(30, 28);
            this.button71.TabIndex = 290;
            this.button71.UseVisualStyleBackColor = true;
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(299, 167);
            this.button70.Margin = new System.Windows.Forms.Padding(1);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(30, 28);
            this.button70.TabIndex = 289;
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(266, 167);
            this.button69.Margin = new System.Windows.Forms.Padding(1);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(30, 28);
            this.button69.TabIndex = 288;
            this.button69.UseVisualStyleBackColor = true;
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(233, 167);
            this.button68.Margin = new System.Windows.Forms.Padding(1);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(30, 28);
            this.button68.TabIndex = 287;
            this.button68.UseVisualStyleBackColor = true;
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(200, 167);
            this.button67.Margin = new System.Windows.Forms.Padding(1);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(30, 28);
            this.button67.TabIndex = 286;
            this.button67.UseVisualStyleBackColor = true;
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(167, 167);
            this.button66.Margin = new System.Windows.Forms.Padding(1);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(30, 28);
            this.button66.TabIndex = 285;
            this.button66.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(134, 167);
            this.button65.Margin = new System.Windows.Forms.Padding(1);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(30, 28);
            this.button65.TabIndex = 284;
            this.button65.UseVisualStyleBackColor = true;
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(101, 167);
            this.button64.Margin = new System.Windows.Forms.Padding(1);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(30, 28);
            this.button64.TabIndex = 283;
            this.button64.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(68, 167);
            this.button63.Margin = new System.Windows.Forms.Padding(1);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(30, 28);
            this.button63.TabIndex = 282;
            this.button63.UseVisualStyleBackColor = true;
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(35, 167);
            this.button62.Margin = new System.Windows.Forms.Padding(1);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(30, 28);
            this.button62.TabIndex = 281;
            this.button62.UseVisualStyleBackColor = true;
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(2, 167);
            this.button61.Margin = new System.Windows.Forms.Padding(1);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(30, 28);
            this.button61.TabIndex = 280;
            this.button61.UseVisualStyleBackColor = true;
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(365, 134);
            this.button60.Margin = new System.Windows.Forms.Padding(1);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(30, 28);
            this.button60.TabIndex = 279;
            this.button60.UseVisualStyleBackColor = true;
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(332, 134);
            this.button59.Margin = new System.Windows.Forms.Padding(1);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(30, 28);
            this.button59.TabIndex = 278;
            this.button59.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(299, 134);
            this.button58.Margin = new System.Windows.Forms.Padding(1);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(30, 28);
            this.button58.TabIndex = 277;
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(266, 134);
            this.button57.Margin = new System.Windows.Forms.Padding(1);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(30, 28);
            this.button57.TabIndex = 276;
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(233, 134);
            this.button56.Margin = new System.Windows.Forms.Padding(1);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(30, 28);
            this.button56.TabIndex = 275;
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(200, 134);
            this.button55.Margin = new System.Windows.Forms.Padding(1);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(30, 28);
            this.button55.TabIndex = 274;
            this.button55.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(167, 134);
            this.button54.Margin = new System.Windows.Forms.Padding(1);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(30, 28);
            this.button54.TabIndex = 273;
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(134, 134);
            this.button53.Margin = new System.Windows.Forms.Padding(1);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(30, 28);
            this.button53.TabIndex = 272;
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(101, 134);
            this.button52.Margin = new System.Windows.Forms.Padding(1);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(30, 28);
            this.button52.TabIndex = 271;
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(68, 134);
            this.button51.Margin = new System.Windows.Forms.Padding(1);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(30, 28);
            this.button51.TabIndex = 270;
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(35, 134);
            this.button50.Margin = new System.Windows.Forms.Padding(1);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(30, 28);
            this.button50.TabIndex = 269;
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(2, 134);
            this.button49.Margin = new System.Windows.Forms.Padding(1);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(30, 28);
            this.button49.TabIndex = 268;
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(365, 101);
            this.button48.Margin = new System.Windows.Forms.Padding(1);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(30, 28);
            this.button48.TabIndex = 267;
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(332, 101);
            this.button47.Margin = new System.Windows.Forms.Padding(1);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(30, 28);
            this.button47.TabIndex = 266;
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(299, 101);
            this.button46.Margin = new System.Windows.Forms.Padding(1);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(30, 28);
            this.button46.TabIndex = 265;
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(266, 101);
            this.button45.Margin = new System.Windows.Forms.Padding(1);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(30, 28);
            this.button45.TabIndex = 264;
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(233, 101);
            this.button44.Margin = new System.Windows.Forms.Padding(1);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(30, 28);
            this.button44.TabIndex = 263;
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(200, 101);
            this.button43.Margin = new System.Windows.Forms.Padding(1);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(30, 28);
            this.button43.TabIndex = 262;
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(167, 101);
            this.button42.Margin = new System.Windows.Forms.Padding(1);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(30, 28);
            this.button42.TabIndex = 261;
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(134, 101);
            this.button41.Margin = new System.Windows.Forms.Padding(1);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(30, 28);
            this.button41.TabIndex = 260;
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(101, 101);
            this.button40.Margin = new System.Windows.Forms.Padding(1);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(30, 28);
            this.button40.TabIndex = 259;
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(68, 101);
            this.button39.Margin = new System.Windows.Forms.Padding(1);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(30, 28);
            this.button39.TabIndex = 258;
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(35, 101);
            this.button38.Margin = new System.Windows.Forms.Padding(1);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(30, 28);
            this.button38.TabIndex = 257;
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(2, 101);
            this.button37.Margin = new System.Windows.Forms.Padding(1);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(30, 28);
            this.button37.TabIndex = 256;
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(365, 68);
            this.button36.Margin = new System.Windows.Forms.Padding(1);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(30, 28);
            this.button36.TabIndex = 255;
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(332, 68);
            this.button35.Margin = new System.Windows.Forms.Padding(1);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(30, 28);
            this.button35.TabIndex = 254;
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(299, 68);
            this.button34.Margin = new System.Windows.Forms.Padding(1);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(30, 28);
            this.button34.TabIndex = 253;
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(266, 68);
            this.button33.Margin = new System.Windows.Forms.Padding(1);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(30, 28);
            this.button33.TabIndex = 252;
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(233, 68);
            this.button32.Margin = new System.Windows.Forms.Padding(1);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(30, 28);
            this.button32.TabIndex = 251;
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(200, 68);
            this.button31.Margin = new System.Windows.Forms.Padding(1);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(30, 28);
            this.button31.TabIndex = 250;
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(167, 68);
            this.button30.Margin = new System.Windows.Forms.Padding(1);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(30, 28);
            this.button30.TabIndex = 249;
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(134, 68);
            this.button29.Margin = new System.Windows.Forms.Padding(1);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(30, 28);
            this.button29.TabIndex = 248;
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(101, 68);
            this.button28.Margin = new System.Windows.Forms.Padding(1);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(30, 28);
            this.button28.TabIndex = 247;
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(68, 68);
            this.button27.Margin = new System.Windows.Forms.Padding(1);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(30, 28);
            this.button27.TabIndex = 246;
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(35, 68);
            this.button26.Margin = new System.Windows.Forms.Padding(1);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(30, 28);
            this.button26.TabIndex = 245;
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(2, 68);
            this.button25.Margin = new System.Windows.Forms.Padding(1);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(30, 28);
            this.button25.TabIndex = 244;
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(365, 35);
            this.button24.Margin = new System.Windows.Forms.Padding(1);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(30, 28);
            this.button24.TabIndex = 243;
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(332, 35);
            this.button23.Margin = new System.Windows.Forms.Padding(1);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(30, 28);
            this.button23.TabIndex = 242;
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(299, 35);
            this.button22.Margin = new System.Windows.Forms.Padding(1);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(30, 28);
            this.button22.TabIndex = 241;
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(266, 35);
            this.button21.Margin = new System.Windows.Forms.Padding(1);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(30, 28);
            this.button21.TabIndex = 240;
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(233, 35);
            this.button20.Margin = new System.Windows.Forms.Padding(1);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(30, 28);
            this.button20.TabIndex = 239;
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(200, 35);
            this.button19.Margin = new System.Windows.Forms.Padding(1);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(30, 28);
            this.button19.TabIndex = 238;
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(167, 35);
            this.button18.Margin = new System.Windows.Forms.Padding(1);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(30, 28);
            this.button18.TabIndex = 237;
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(134, 35);
            this.button17.Margin = new System.Windows.Forms.Padding(1);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(30, 28);
            this.button17.TabIndex = 236;
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(101, 35);
            this.button16.Margin = new System.Windows.Forms.Padding(1);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(30, 28);
            this.button16.TabIndex = 235;
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(68, 35);
            this.button15.Margin = new System.Windows.Forms.Padding(1);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(30, 28);
            this.button15.TabIndex = 234;
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(35, 35);
            this.button14.Margin = new System.Windows.Forms.Padding(1);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(30, 28);
            this.button14.TabIndex = 233;
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(2, 35);
            this.button13.Margin = new System.Windows.Forms.Padding(1);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(30, 28);
            this.button13.TabIndex = 232;
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(365, 2);
            this.button12.Margin = new System.Windows.Forms.Padding(1);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(30, 28);
            this.button12.TabIndex = 231;
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(332, 2);
            this.button11.Margin = new System.Windows.Forms.Padding(1);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(30, 28);
            this.button11.TabIndex = 230;
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(299, 2);
            this.button10.Margin = new System.Windows.Forms.Padding(1);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(30, 28);
            this.button10.TabIndex = 229;
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(266, 2);
            this.button9.Margin = new System.Windows.Forms.Padding(1);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(30, 28);
            this.button9.TabIndex = 228;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(233, 2);
            this.button8.Margin = new System.Windows.Forms.Padding(1);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(30, 28);
            this.button8.TabIndex = 227;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(200, 2);
            this.button7.Margin = new System.Windows.Forms.Padding(1);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(30, 28);
            this.button7.TabIndex = 226;
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(167, 2);
            this.button6.Margin = new System.Windows.Forms.Padding(1);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(30, 28);
            this.button6.TabIndex = 225;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(134, 2);
            this.button5.Margin = new System.Windows.Forms.Padding(1);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(30, 28);
            this.button5.TabIndex = 224;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(101, 2);
            this.button4.Margin = new System.Windows.Forms.Padding(1);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(30, 28);
            this.button4.TabIndex = 223;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(68, 2);
            this.button3.Margin = new System.Windows.Forms.Padding(1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(30, 28);
            this.button3.TabIndex = 222;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(35, 2);
            this.button2.Margin = new System.Windows.Forms.Padding(1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(30, 28);
            this.button2.TabIndex = 221;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.LightSeaGreen;
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 12;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333335F));
            this.tableLayoutPanel2.Controls.Add(this.button288, 11, 11);
            this.tableLayoutPanel2.Controls.Add(this.button287, 10, 11);
            this.tableLayoutPanel2.Controls.Add(this.button286, 9, 11);
            this.tableLayoutPanel2.Controls.Add(this.button285, 8, 11);
            this.tableLayoutPanel2.Controls.Add(this.button284, 7, 11);
            this.tableLayoutPanel2.Controls.Add(this.button283, 6, 11);
            this.tableLayoutPanel2.Controls.Add(this.button282, 5, 11);
            this.tableLayoutPanel2.Controls.Add(this.button281, 4, 11);
            this.tableLayoutPanel2.Controls.Add(this.button280, 3, 11);
            this.tableLayoutPanel2.Controls.Add(this.button279, 2, 11);
            this.tableLayoutPanel2.Controls.Add(this.button278, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.button277, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.button276, 11, 10);
            this.tableLayoutPanel2.Controls.Add(this.button275, 10, 10);
            this.tableLayoutPanel2.Controls.Add(this.button274, 9, 10);
            this.tableLayoutPanel2.Controls.Add(this.button273, 8, 10);
            this.tableLayoutPanel2.Controls.Add(this.button272, 7, 10);
            this.tableLayoutPanel2.Controls.Add(this.button271, 6, 10);
            this.tableLayoutPanel2.Controls.Add(this.button270, 5, 10);
            this.tableLayoutPanel2.Controls.Add(this.button269, 4, 10);
            this.tableLayoutPanel2.Controls.Add(this.button268, 3, 10);
            this.tableLayoutPanel2.Controls.Add(this.button267, 2, 10);
            this.tableLayoutPanel2.Controls.Add(this.button266, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.button265, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.button264, 11, 9);
            this.tableLayoutPanel2.Controls.Add(this.button263, 10, 9);
            this.tableLayoutPanel2.Controls.Add(this.button262, 9, 9);
            this.tableLayoutPanel2.Controls.Add(this.button261, 8, 9);
            this.tableLayoutPanel2.Controls.Add(this.button260, 7, 9);
            this.tableLayoutPanel2.Controls.Add(this.button259, 6, 9);
            this.tableLayoutPanel2.Controls.Add(this.button258, 5, 9);
            this.tableLayoutPanel2.Controls.Add(this.button257, 4, 9);
            this.tableLayoutPanel2.Controls.Add(this.button256, 3, 9);
            this.tableLayoutPanel2.Controls.Add(this.button255, 2, 9);
            this.tableLayoutPanel2.Controls.Add(this.button254, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.button253, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.button252, 11, 8);
            this.tableLayoutPanel2.Controls.Add(this.button251, 10, 8);
            this.tableLayoutPanel2.Controls.Add(this.button250, 9, 8);
            this.tableLayoutPanel2.Controls.Add(this.button249, 8, 8);
            this.tableLayoutPanel2.Controls.Add(this.button248, 7, 8);
            this.tableLayoutPanel2.Controls.Add(this.button247, 6, 8);
            this.tableLayoutPanel2.Controls.Add(this.button246, 5, 8);
            this.tableLayoutPanel2.Controls.Add(this.button245, 4, 8);
            this.tableLayoutPanel2.Controls.Add(this.button244, 3, 8);
            this.tableLayoutPanel2.Controls.Add(this.button243, 2, 8);
            this.tableLayoutPanel2.Controls.Add(this.button242, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.button241, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.button240, 11, 7);
            this.tableLayoutPanel2.Controls.Add(this.button239, 10, 7);
            this.tableLayoutPanel2.Controls.Add(this.button238, 9, 7);
            this.tableLayoutPanel2.Controls.Add(this.button237, 8, 7);
            this.tableLayoutPanel2.Controls.Add(this.button236, 7, 7);
            this.tableLayoutPanel2.Controls.Add(this.button235, 6, 7);
            this.tableLayoutPanel2.Controls.Add(this.button234, 5, 7);
            this.tableLayoutPanel2.Controls.Add(this.button233, 4, 7);
            this.tableLayoutPanel2.Controls.Add(this.button232, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.button231, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.button230, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.button229, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.button228, 11, 6);
            this.tableLayoutPanel2.Controls.Add(this.button227, 10, 6);
            this.tableLayoutPanel2.Controls.Add(this.button226, 9, 6);
            this.tableLayoutPanel2.Controls.Add(this.button225, 8, 6);
            this.tableLayoutPanel2.Controls.Add(this.button224, 7, 6);
            this.tableLayoutPanel2.Controls.Add(this.button223, 6, 6);
            this.tableLayoutPanel2.Controls.Add(this.button222, 5, 6);
            this.tableLayoutPanel2.Controls.Add(this.button221, 4, 6);
            this.tableLayoutPanel2.Controls.Add(this.button220, 3, 6);
            this.tableLayoutPanel2.Controls.Add(this.button219, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.button218, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.button217, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.button215, 11, 5);
            this.tableLayoutPanel2.Controls.Add(this.button214, 10, 5);
            this.tableLayoutPanel2.Controls.Add(this.button213, 9, 5);
            this.tableLayoutPanel2.Controls.Add(this.button212, 8, 5);
            this.tableLayoutPanel2.Controls.Add(this.button211, 7, 5);
            this.tableLayoutPanel2.Controls.Add(this.button210, 6, 5);
            this.tableLayoutPanel2.Controls.Add(this.button209, 5, 5);
            this.tableLayoutPanel2.Controls.Add(this.button208, 4, 5);
            this.tableLayoutPanel2.Controls.Add(this.button207, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.button206, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.button205, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.button204, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.button203, 11, 4);
            this.tableLayoutPanel2.Controls.Add(this.button202, 10, 4);
            this.tableLayoutPanel2.Controls.Add(this.button201, 9, 4);
            this.tableLayoutPanel2.Controls.Add(this.button200, 8, 4);
            this.tableLayoutPanel2.Controls.Add(this.button199, 7, 4);
            this.tableLayoutPanel2.Controls.Add(this.button198, 6, 4);
            this.tableLayoutPanel2.Controls.Add(this.button197, 5, 4);
            this.tableLayoutPanel2.Controls.Add(this.button196, 4, 4);
            this.tableLayoutPanel2.Controls.Add(this.button195, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.button194, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.button193, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.button192, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.button191, 11, 3);
            this.tableLayoutPanel2.Controls.Add(this.button190, 10, 3);
            this.tableLayoutPanel2.Controls.Add(this.button189, 9, 3);
            this.tableLayoutPanel2.Controls.Add(this.button188, 8, 3);
            this.tableLayoutPanel2.Controls.Add(this.button187, 7, 3);
            this.tableLayoutPanel2.Controls.Add(this.button186, 6, 3);
            this.tableLayoutPanel2.Controls.Add(this.button185, 5, 3);
            this.tableLayoutPanel2.Controls.Add(this.button184, 4, 3);
            this.tableLayoutPanel2.Controls.Add(this.button183, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.button182, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.button181, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.button180, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.button179, 11, 2);
            this.tableLayoutPanel2.Controls.Add(this.button178, 10, 2);
            this.tableLayoutPanel2.Controls.Add(this.button177, 9, 2);
            this.tableLayoutPanel2.Controls.Add(this.button176, 8, 2);
            this.tableLayoutPanel2.Controls.Add(this.button175, 7, 2);
            this.tableLayoutPanel2.Controls.Add(this.button174, 6, 2);
            this.tableLayoutPanel2.Controls.Add(this.button173, 5, 2);
            this.tableLayoutPanel2.Controls.Add(this.button172, 4, 2);
            this.tableLayoutPanel2.Controls.Add(this.button171, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.button170, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.button169, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.button168, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.button167, 11, 1);
            this.tableLayoutPanel2.Controls.Add(this.button166, 10, 1);
            this.tableLayoutPanel2.Controls.Add(this.button165, 9, 1);
            this.tableLayoutPanel2.Controls.Add(this.button164, 8, 1);
            this.tableLayoutPanel2.Controls.Add(this.button163, 7, 1);
            this.tableLayoutPanel2.Controls.Add(this.button162, 6, 1);
            this.tableLayoutPanel2.Controls.Add(this.button161, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.button160, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.button159, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.button158, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.button157, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.button156, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.button155, 11, 0);
            this.tableLayoutPanel2.Controls.Add(this.button154, 10, 0);
            this.tableLayoutPanel2.Controls.Add(this.button153, 9, 0);
            this.tableLayoutPanel2.Controls.Add(this.button152, 8, 0);
            this.tableLayoutPanel2.Controls.Add(this.button151, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.button150, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.button216, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.button149, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.button146, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.button145, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.button148, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.button147, 3, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(534, 98);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 12;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(400, 400);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // button288
            // 
            this.button288.Location = new System.Drawing.Point(365, 365);
            this.button288.Margin = new System.Windows.Forms.Padding(1);
            this.button288.Name = "button288";
            this.button288.Size = new System.Drawing.Size(30, 30);
            this.button288.TabIndex = 364;
            this.button288.UseVisualStyleBackColor = true;
            // 
            // button287
            // 
            this.button287.Location = new System.Drawing.Point(332, 365);
            this.button287.Margin = new System.Windows.Forms.Padding(1);
            this.button287.Name = "button287";
            this.button287.Size = new System.Drawing.Size(30, 30);
            this.button287.TabIndex = 220;
            this.button287.UseVisualStyleBackColor = true;
            // 
            // button286
            // 
            this.button286.Location = new System.Drawing.Point(299, 365);
            this.button286.Margin = new System.Windows.Forms.Padding(1);
            this.button286.Name = "button286";
            this.button286.Size = new System.Drawing.Size(30, 30);
            this.button286.TabIndex = 219;
            this.button286.UseVisualStyleBackColor = true;
            // 
            // button285
            // 
            this.button285.Location = new System.Drawing.Point(266, 365);
            this.button285.Margin = new System.Windows.Forms.Padding(1);
            this.button285.Name = "button285";
            this.button285.Size = new System.Drawing.Size(30, 30);
            this.button285.TabIndex = 218;
            this.button285.UseVisualStyleBackColor = true;
            // 
            // button284
            // 
            this.button284.Location = new System.Drawing.Point(233, 365);
            this.button284.Margin = new System.Windows.Forms.Padding(1);
            this.button284.Name = "button284";
            this.button284.Size = new System.Drawing.Size(30, 30);
            this.button284.TabIndex = 217;
            this.button284.UseVisualStyleBackColor = true;
            // 
            // button283
            // 
            this.button283.Location = new System.Drawing.Point(200, 365);
            this.button283.Margin = new System.Windows.Forms.Padding(1);
            this.button283.Name = "button283";
            this.button283.Size = new System.Drawing.Size(30, 30);
            this.button283.TabIndex = 216;
            this.button283.UseVisualStyleBackColor = true;
            // 
            // button282
            // 
            this.button282.Location = new System.Drawing.Point(167, 365);
            this.button282.Margin = new System.Windows.Forms.Padding(1);
            this.button282.Name = "button282";
            this.button282.Size = new System.Drawing.Size(30, 30);
            this.button282.TabIndex = 215;
            this.button282.UseVisualStyleBackColor = true;
            // 
            // button281
            // 
            this.button281.Location = new System.Drawing.Point(134, 365);
            this.button281.Margin = new System.Windows.Forms.Padding(1);
            this.button281.Name = "button281";
            this.button281.Size = new System.Drawing.Size(30, 30);
            this.button281.TabIndex = 214;
            this.button281.UseVisualStyleBackColor = true;
            // 
            // button280
            // 
            this.button280.Location = new System.Drawing.Point(101, 365);
            this.button280.Margin = new System.Windows.Forms.Padding(1);
            this.button280.Name = "button280";
            this.button280.Size = new System.Drawing.Size(30, 30);
            this.button280.TabIndex = 213;
            this.button280.UseVisualStyleBackColor = true;
            // 
            // button279
            // 
            this.button279.Location = new System.Drawing.Point(68, 365);
            this.button279.Margin = new System.Windows.Forms.Padding(1);
            this.button279.Name = "button279";
            this.button279.Size = new System.Drawing.Size(30, 30);
            this.button279.TabIndex = 212;
            this.button279.UseVisualStyleBackColor = true;
            // 
            // button278
            // 
            this.button278.Location = new System.Drawing.Point(35, 365);
            this.button278.Margin = new System.Windows.Forms.Padding(1);
            this.button278.Name = "button278";
            this.button278.Size = new System.Drawing.Size(30, 30);
            this.button278.TabIndex = 211;
            this.button278.UseVisualStyleBackColor = true;
            // 
            // button277
            // 
            this.button277.Location = new System.Drawing.Point(2, 365);
            this.button277.Margin = new System.Windows.Forms.Padding(1);
            this.button277.Name = "button277";
            this.button277.Size = new System.Drawing.Size(30, 30);
            this.button277.TabIndex = 210;
            this.button277.UseVisualStyleBackColor = true;
            // 
            // button276
            // 
            this.button276.Location = new System.Drawing.Point(365, 332);
            this.button276.Margin = new System.Windows.Forms.Padding(1);
            this.button276.Name = "button276";
            this.button276.Size = new System.Drawing.Size(30, 30);
            this.button276.TabIndex = 209;
            this.button276.UseVisualStyleBackColor = true;
            // 
            // button275
            // 
            this.button275.Location = new System.Drawing.Point(332, 332);
            this.button275.Margin = new System.Windows.Forms.Padding(1);
            this.button275.Name = "button275";
            this.button275.Size = new System.Drawing.Size(30, 30);
            this.button275.TabIndex = 208;
            this.button275.UseVisualStyleBackColor = true;
            // 
            // button274
            // 
            this.button274.Location = new System.Drawing.Point(299, 332);
            this.button274.Margin = new System.Windows.Forms.Padding(1);
            this.button274.Name = "button274";
            this.button274.Size = new System.Drawing.Size(30, 30);
            this.button274.TabIndex = 207;
            this.button274.UseVisualStyleBackColor = true;
            // 
            // button273
            // 
            this.button273.Location = new System.Drawing.Point(266, 332);
            this.button273.Margin = new System.Windows.Forms.Padding(1);
            this.button273.Name = "button273";
            this.button273.Size = new System.Drawing.Size(30, 30);
            this.button273.TabIndex = 206;
            this.button273.UseVisualStyleBackColor = true;
            // 
            // button272
            // 
            this.button272.Location = new System.Drawing.Point(233, 332);
            this.button272.Margin = new System.Windows.Forms.Padding(1);
            this.button272.Name = "button272";
            this.button272.Size = new System.Drawing.Size(30, 30);
            this.button272.TabIndex = 205;
            this.button272.UseVisualStyleBackColor = true;
            // 
            // button271
            // 
            this.button271.Location = new System.Drawing.Point(200, 332);
            this.button271.Margin = new System.Windows.Forms.Padding(1);
            this.button271.Name = "button271";
            this.button271.Size = new System.Drawing.Size(30, 30);
            this.button271.TabIndex = 204;
            this.button271.UseVisualStyleBackColor = true;
            // 
            // button270
            // 
            this.button270.Location = new System.Drawing.Point(167, 332);
            this.button270.Margin = new System.Windows.Forms.Padding(1);
            this.button270.Name = "button270";
            this.button270.Size = new System.Drawing.Size(30, 30);
            this.button270.TabIndex = 203;
            this.button270.UseVisualStyleBackColor = true;
            // 
            // button269
            // 
            this.button269.Location = new System.Drawing.Point(134, 332);
            this.button269.Margin = new System.Windows.Forms.Padding(1);
            this.button269.Name = "button269";
            this.button269.Size = new System.Drawing.Size(30, 30);
            this.button269.TabIndex = 202;
            this.button269.UseVisualStyleBackColor = true;
            // 
            // button268
            // 
            this.button268.Location = new System.Drawing.Point(101, 332);
            this.button268.Margin = new System.Windows.Forms.Padding(1);
            this.button268.Name = "button268";
            this.button268.Size = new System.Drawing.Size(30, 30);
            this.button268.TabIndex = 201;
            this.button268.UseVisualStyleBackColor = true;
            // 
            // button267
            // 
            this.button267.Location = new System.Drawing.Point(68, 332);
            this.button267.Margin = new System.Windows.Forms.Padding(1);
            this.button267.Name = "button267";
            this.button267.Size = new System.Drawing.Size(30, 30);
            this.button267.TabIndex = 200;
            this.button267.UseVisualStyleBackColor = true;
            // 
            // button266
            // 
            this.button266.Location = new System.Drawing.Point(35, 332);
            this.button266.Margin = new System.Windows.Forms.Padding(1);
            this.button266.Name = "button266";
            this.button266.Size = new System.Drawing.Size(30, 30);
            this.button266.TabIndex = 199;
            this.button266.UseVisualStyleBackColor = true;
            // 
            // button265
            // 
            this.button265.Location = new System.Drawing.Point(2, 332);
            this.button265.Margin = new System.Windows.Forms.Padding(1);
            this.button265.Name = "button265";
            this.button265.Size = new System.Drawing.Size(30, 30);
            this.button265.TabIndex = 198;
            this.button265.UseVisualStyleBackColor = true;
            // 
            // button264
            // 
            this.button264.Location = new System.Drawing.Point(365, 299);
            this.button264.Margin = new System.Windows.Forms.Padding(1);
            this.button264.Name = "button264";
            this.button264.Size = new System.Drawing.Size(30, 30);
            this.button264.TabIndex = 197;
            this.button264.UseVisualStyleBackColor = true;
            // 
            // button263
            // 
            this.button263.Location = new System.Drawing.Point(332, 299);
            this.button263.Margin = new System.Windows.Forms.Padding(1);
            this.button263.Name = "button263";
            this.button263.Size = new System.Drawing.Size(30, 30);
            this.button263.TabIndex = 196;
            this.button263.UseVisualStyleBackColor = true;
            // 
            // button262
            // 
            this.button262.Location = new System.Drawing.Point(299, 299);
            this.button262.Margin = new System.Windows.Forms.Padding(1);
            this.button262.Name = "button262";
            this.button262.Size = new System.Drawing.Size(30, 30);
            this.button262.TabIndex = 195;
            this.button262.UseVisualStyleBackColor = true;
            // 
            // button261
            // 
            this.button261.Location = new System.Drawing.Point(266, 299);
            this.button261.Margin = new System.Windows.Forms.Padding(1);
            this.button261.Name = "button261";
            this.button261.Size = new System.Drawing.Size(30, 30);
            this.button261.TabIndex = 194;
            this.button261.UseVisualStyleBackColor = true;
            // 
            // button260
            // 
            this.button260.Location = new System.Drawing.Point(233, 299);
            this.button260.Margin = new System.Windows.Forms.Padding(1);
            this.button260.Name = "button260";
            this.button260.Size = new System.Drawing.Size(30, 30);
            this.button260.TabIndex = 193;
            this.button260.UseVisualStyleBackColor = true;
            // 
            // button259
            // 
            this.button259.Location = new System.Drawing.Point(200, 299);
            this.button259.Margin = new System.Windows.Forms.Padding(1);
            this.button259.Name = "button259";
            this.button259.Size = new System.Drawing.Size(30, 30);
            this.button259.TabIndex = 192;
            this.button259.UseVisualStyleBackColor = true;
            // 
            // button258
            // 
            this.button258.Location = new System.Drawing.Point(167, 299);
            this.button258.Margin = new System.Windows.Forms.Padding(1);
            this.button258.Name = "button258";
            this.button258.Size = new System.Drawing.Size(30, 30);
            this.button258.TabIndex = 191;
            this.button258.UseVisualStyleBackColor = true;
            // 
            // button257
            // 
            this.button257.Location = new System.Drawing.Point(134, 299);
            this.button257.Margin = new System.Windows.Forms.Padding(1);
            this.button257.Name = "button257";
            this.button257.Size = new System.Drawing.Size(30, 30);
            this.button257.TabIndex = 190;
            this.button257.UseVisualStyleBackColor = true;
            // 
            // button256
            // 
            this.button256.Location = new System.Drawing.Point(101, 299);
            this.button256.Margin = new System.Windows.Forms.Padding(1);
            this.button256.Name = "button256";
            this.button256.Size = new System.Drawing.Size(30, 30);
            this.button256.TabIndex = 189;
            this.button256.UseVisualStyleBackColor = true;
            // 
            // button255
            // 
            this.button255.Location = new System.Drawing.Point(68, 299);
            this.button255.Margin = new System.Windows.Forms.Padding(1);
            this.button255.Name = "button255";
            this.button255.Size = new System.Drawing.Size(30, 30);
            this.button255.TabIndex = 188;
            this.button255.UseVisualStyleBackColor = true;
            // 
            // button254
            // 
            this.button254.Location = new System.Drawing.Point(35, 299);
            this.button254.Margin = new System.Windows.Forms.Padding(1);
            this.button254.Name = "button254";
            this.button254.Size = new System.Drawing.Size(30, 30);
            this.button254.TabIndex = 187;
            this.button254.UseVisualStyleBackColor = true;
            // 
            // button253
            // 
            this.button253.Location = new System.Drawing.Point(2, 299);
            this.button253.Margin = new System.Windows.Forms.Padding(1);
            this.button253.Name = "button253";
            this.button253.Size = new System.Drawing.Size(30, 30);
            this.button253.TabIndex = 186;
            this.button253.UseVisualStyleBackColor = true;
            // 
            // button252
            // 
            this.button252.Location = new System.Drawing.Point(365, 266);
            this.button252.Margin = new System.Windows.Forms.Padding(1);
            this.button252.Name = "button252";
            this.button252.Size = new System.Drawing.Size(30, 30);
            this.button252.TabIndex = 185;
            this.button252.UseVisualStyleBackColor = true;
            // 
            // button251
            // 
            this.button251.Location = new System.Drawing.Point(332, 266);
            this.button251.Margin = new System.Windows.Forms.Padding(1);
            this.button251.Name = "button251";
            this.button251.Size = new System.Drawing.Size(30, 30);
            this.button251.TabIndex = 184;
            this.button251.UseVisualStyleBackColor = true;
            // 
            // button250
            // 
            this.button250.Location = new System.Drawing.Point(299, 266);
            this.button250.Margin = new System.Windows.Forms.Padding(1);
            this.button250.Name = "button250";
            this.button250.Size = new System.Drawing.Size(30, 30);
            this.button250.TabIndex = 183;
            this.button250.UseVisualStyleBackColor = true;
            // 
            // button249
            // 
            this.button249.Location = new System.Drawing.Point(266, 266);
            this.button249.Margin = new System.Windows.Forms.Padding(1);
            this.button249.Name = "button249";
            this.button249.Size = new System.Drawing.Size(30, 30);
            this.button249.TabIndex = 182;
            this.button249.UseVisualStyleBackColor = true;
            // 
            // button248
            // 
            this.button248.Location = new System.Drawing.Point(233, 266);
            this.button248.Margin = new System.Windows.Forms.Padding(1);
            this.button248.Name = "button248";
            this.button248.Size = new System.Drawing.Size(30, 30);
            this.button248.TabIndex = 181;
            this.button248.UseVisualStyleBackColor = true;
            // 
            // button247
            // 
            this.button247.Location = new System.Drawing.Point(200, 266);
            this.button247.Margin = new System.Windows.Forms.Padding(1);
            this.button247.Name = "button247";
            this.button247.Size = new System.Drawing.Size(30, 30);
            this.button247.TabIndex = 180;
            this.button247.UseVisualStyleBackColor = true;
            // 
            // button246
            // 
            this.button246.Location = new System.Drawing.Point(167, 266);
            this.button246.Margin = new System.Windows.Forms.Padding(1);
            this.button246.Name = "button246";
            this.button246.Size = new System.Drawing.Size(30, 30);
            this.button246.TabIndex = 179;
            this.button246.UseVisualStyleBackColor = true;
            // 
            // button245
            // 
            this.button245.Location = new System.Drawing.Point(134, 266);
            this.button245.Margin = new System.Windows.Forms.Padding(1);
            this.button245.Name = "button245";
            this.button245.Size = new System.Drawing.Size(30, 30);
            this.button245.TabIndex = 178;
            this.button245.UseVisualStyleBackColor = true;
            // 
            // button244
            // 
            this.button244.Location = new System.Drawing.Point(101, 266);
            this.button244.Margin = new System.Windows.Forms.Padding(1);
            this.button244.Name = "button244";
            this.button244.Size = new System.Drawing.Size(30, 30);
            this.button244.TabIndex = 177;
            this.button244.UseVisualStyleBackColor = true;
            // 
            // button243
            // 
            this.button243.Location = new System.Drawing.Point(68, 266);
            this.button243.Margin = new System.Windows.Forms.Padding(1);
            this.button243.Name = "button243";
            this.button243.Size = new System.Drawing.Size(30, 30);
            this.button243.TabIndex = 176;
            this.button243.UseVisualStyleBackColor = true;
            // 
            // button242
            // 
            this.button242.Location = new System.Drawing.Point(35, 266);
            this.button242.Margin = new System.Windows.Forms.Padding(1);
            this.button242.Name = "button242";
            this.button242.Size = new System.Drawing.Size(30, 30);
            this.button242.TabIndex = 175;
            this.button242.UseVisualStyleBackColor = true;
            // 
            // button241
            // 
            this.button241.Location = new System.Drawing.Point(2, 266);
            this.button241.Margin = new System.Windows.Forms.Padding(1);
            this.button241.Name = "button241";
            this.button241.Size = new System.Drawing.Size(30, 30);
            this.button241.TabIndex = 174;
            this.button241.UseVisualStyleBackColor = true;
            // 
            // button240
            // 
            this.button240.Location = new System.Drawing.Point(365, 233);
            this.button240.Margin = new System.Windows.Forms.Padding(1);
            this.button240.Name = "button240";
            this.button240.Size = new System.Drawing.Size(30, 30);
            this.button240.TabIndex = 173;
            this.button240.UseVisualStyleBackColor = true;
            // 
            // button239
            // 
            this.button239.Location = new System.Drawing.Point(332, 233);
            this.button239.Margin = new System.Windows.Forms.Padding(1);
            this.button239.Name = "button239";
            this.button239.Size = new System.Drawing.Size(30, 30);
            this.button239.TabIndex = 172;
            this.button239.UseVisualStyleBackColor = true;
            // 
            // button238
            // 
            this.button238.Location = new System.Drawing.Point(299, 233);
            this.button238.Margin = new System.Windows.Forms.Padding(1);
            this.button238.Name = "button238";
            this.button238.Size = new System.Drawing.Size(30, 30);
            this.button238.TabIndex = 171;
            this.button238.UseVisualStyleBackColor = true;
            // 
            // button237
            // 
            this.button237.Location = new System.Drawing.Point(266, 233);
            this.button237.Margin = new System.Windows.Forms.Padding(1);
            this.button237.Name = "button237";
            this.button237.Size = new System.Drawing.Size(30, 30);
            this.button237.TabIndex = 170;
            this.button237.UseVisualStyleBackColor = true;
            // 
            // button236
            // 
            this.button236.Location = new System.Drawing.Point(233, 233);
            this.button236.Margin = new System.Windows.Forms.Padding(1);
            this.button236.Name = "button236";
            this.button236.Size = new System.Drawing.Size(30, 30);
            this.button236.TabIndex = 169;
            this.button236.UseVisualStyleBackColor = true;
            // 
            // button235
            // 
            this.button235.Location = new System.Drawing.Point(200, 233);
            this.button235.Margin = new System.Windows.Forms.Padding(1);
            this.button235.Name = "button235";
            this.button235.Size = new System.Drawing.Size(30, 30);
            this.button235.TabIndex = 168;
            this.button235.UseVisualStyleBackColor = true;
            // 
            // button234
            // 
            this.button234.Location = new System.Drawing.Point(167, 233);
            this.button234.Margin = new System.Windows.Forms.Padding(1);
            this.button234.Name = "button234";
            this.button234.Size = new System.Drawing.Size(30, 30);
            this.button234.TabIndex = 167;
            this.button234.UseVisualStyleBackColor = true;
            // 
            // button233
            // 
            this.button233.Location = new System.Drawing.Point(134, 233);
            this.button233.Margin = new System.Windows.Forms.Padding(1);
            this.button233.Name = "button233";
            this.button233.Size = new System.Drawing.Size(30, 30);
            this.button233.TabIndex = 166;
            this.button233.UseVisualStyleBackColor = true;
            // 
            // button232
            // 
            this.button232.Location = new System.Drawing.Point(101, 233);
            this.button232.Margin = new System.Windows.Forms.Padding(1);
            this.button232.Name = "button232";
            this.button232.Size = new System.Drawing.Size(30, 30);
            this.button232.TabIndex = 165;
            this.button232.UseVisualStyleBackColor = true;
            // 
            // button231
            // 
            this.button231.Location = new System.Drawing.Point(68, 233);
            this.button231.Margin = new System.Windows.Forms.Padding(1);
            this.button231.Name = "button231";
            this.button231.Size = new System.Drawing.Size(30, 30);
            this.button231.TabIndex = 164;
            this.button231.UseVisualStyleBackColor = true;
            // 
            // button230
            // 
            this.button230.Location = new System.Drawing.Point(35, 233);
            this.button230.Margin = new System.Windows.Forms.Padding(1);
            this.button230.Name = "button230";
            this.button230.Size = new System.Drawing.Size(30, 30);
            this.button230.TabIndex = 163;
            this.button230.UseVisualStyleBackColor = true;
            // 
            // button229
            // 
            this.button229.Location = new System.Drawing.Point(2, 233);
            this.button229.Margin = new System.Windows.Forms.Padding(1);
            this.button229.Name = "button229";
            this.button229.Size = new System.Drawing.Size(30, 30);
            this.button229.TabIndex = 162;
            this.button229.UseVisualStyleBackColor = true;
            // 
            // button228
            // 
            this.button228.Location = new System.Drawing.Point(365, 200);
            this.button228.Margin = new System.Windows.Forms.Padding(1);
            this.button228.Name = "button228";
            this.button228.Size = new System.Drawing.Size(30, 30);
            this.button228.TabIndex = 161;
            this.button228.UseVisualStyleBackColor = true;
            // 
            // button227
            // 
            this.button227.Location = new System.Drawing.Point(332, 200);
            this.button227.Margin = new System.Windows.Forms.Padding(1);
            this.button227.Name = "button227";
            this.button227.Size = new System.Drawing.Size(30, 30);
            this.button227.TabIndex = 160;
            this.button227.UseVisualStyleBackColor = true;
            // 
            // button226
            // 
            this.button226.Location = new System.Drawing.Point(299, 200);
            this.button226.Margin = new System.Windows.Forms.Padding(1);
            this.button226.Name = "button226";
            this.button226.Size = new System.Drawing.Size(30, 30);
            this.button226.TabIndex = 159;
            this.button226.UseVisualStyleBackColor = true;
            // 
            // button225
            // 
            this.button225.Location = new System.Drawing.Point(266, 200);
            this.button225.Margin = new System.Windows.Forms.Padding(1);
            this.button225.Name = "button225";
            this.button225.Size = new System.Drawing.Size(30, 30);
            this.button225.TabIndex = 158;
            this.button225.UseVisualStyleBackColor = true;
            // 
            // button224
            // 
            this.button224.Location = new System.Drawing.Point(233, 200);
            this.button224.Margin = new System.Windows.Forms.Padding(1);
            this.button224.Name = "button224";
            this.button224.Size = new System.Drawing.Size(30, 30);
            this.button224.TabIndex = 157;
            this.button224.UseVisualStyleBackColor = true;
            // 
            // button223
            // 
            this.button223.Location = new System.Drawing.Point(200, 200);
            this.button223.Margin = new System.Windows.Forms.Padding(1);
            this.button223.Name = "button223";
            this.button223.Size = new System.Drawing.Size(30, 30);
            this.button223.TabIndex = 156;
            this.button223.UseVisualStyleBackColor = true;
            // 
            // button222
            // 
            this.button222.Location = new System.Drawing.Point(167, 200);
            this.button222.Margin = new System.Windows.Forms.Padding(1);
            this.button222.Name = "button222";
            this.button222.Size = new System.Drawing.Size(30, 30);
            this.button222.TabIndex = 155;
            this.button222.UseVisualStyleBackColor = true;
            // 
            // button221
            // 
            this.button221.Location = new System.Drawing.Point(134, 200);
            this.button221.Margin = new System.Windows.Forms.Padding(1);
            this.button221.Name = "button221";
            this.button221.Size = new System.Drawing.Size(30, 30);
            this.button221.TabIndex = 154;
            this.button221.UseVisualStyleBackColor = true;
            // 
            // button220
            // 
            this.button220.Location = new System.Drawing.Point(101, 200);
            this.button220.Margin = new System.Windows.Forms.Padding(1);
            this.button220.Name = "button220";
            this.button220.Size = new System.Drawing.Size(30, 30);
            this.button220.TabIndex = 153;
            this.button220.UseVisualStyleBackColor = true;
            // 
            // button219
            // 
            this.button219.Location = new System.Drawing.Point(68, 200);
            this.button219.Margin = new System.Windows.Forms.Padding(1);
            this.button219.Name = "button219";
            this.button219.Size = new System.Drawing.Size(30, 30);
            this.button219.TabIndex = 152;
            this.button219.UseVisualStyleBackColor = true;
            // 
            // button218
            // 
            this.button218.Location = new System.Drawing.Point(35, 200);
            this.button218.Margin = new System.Windows.Forms.Padding(1);
            this.button218.Name = "button218";
            this.button218.Size = new System.Drawing.Size(30, 30);
            this.button218.TabIndex = 151;
            this.button218.UseVisualStyleBackColor = true;
            // 
            // button217
            // 
            this.button217.Location = new System.Drawing.Point(2, 200);
            this.button217.Margin = new System.Windows.Forms.Padding(1);
            this.button217.Name = "button217";
            this.button217.Size = new System.Drawing.Size(30, 30);
            this.button217.TabIndex = 150;
            this.button217.UseVisualStyleBackColor = true;
            // 
            // button215
            // 
            this.button215.Location = new System.Drawing.Point(365, 167);
            this.button215.Margin = new System.Windows.Forms.Padding(1);
            this.button215.Name = "button215";
            this.button215.Size = new System.Drawing.Size(30, 30);
            this.button215.TabIndex = 149;
            this.button215.UseVisualStyleBackColor = true;
            // 
            // button214
            // 
            this.button214.Location = new System.Drawing.Point(332, 167);
            this.button214.Margin = new System.Windows.Forms.Padding(1);
            this.button214.Name = "button214";
            this.button214.Size = new System.Drawing.Size(30, 30);
            this.button214.TabIndex = 148;
            this.button214.UseVisualStyleBackColor = true;
            // 
            // button213
            // 
            this.button213.Location = new System.Drawing.Point(299, 167);
            this.button213.Margin = new System.Windows.Forms.Padding(1);
            this.button213.Name = "button213";
            this.button213.Size = new System.Drawing.Size(30, 30);
            this.button213.TabIndex = 147;
            this.button213.UseVisualStyleBackColor = true;
            // 
            // button212
            // 
            this.button212.Location = new System.Drawing.Point(266, 167);
            this.button212.Margin = new System.Windows.Forms.Padding(1);
            this.button212.Name = "button212";
            this.button212.Size = new System.Drawing.Size(30, 30);
            this.button212.TabIndex = 146;
            this.button212.UseVisualStyleBackColor = true;
            // 
            // button211
            // 
            this.button211.Location = new System.Drawing.Point(233, 167);
            this.button211.Margin = new System.Windows.Forms.Padding(1);
            this.button211.Name = "button211";
            this.button211.Size = new System.Drawing.Size(30, 30);
            this.button211.TabIndex = 145;
            this.button211.UseVisualStyleBackColor = true;
            // 
            // button210
            // 
            this.button210.Location = new System.Drawing.Point(200, 167);
            this.button210.Margin = new System.Windows.Forms.Padding(1);
            this.button210.Name = "button210";
            this.button210.Size = new System.Drawing.Size(30, 30);
            this.button210.TabIndex = 144;
            this.button210.UseVisualStyleBackColor = true;
            // 
            // button209
            // 
            this.button209.Location = new System.Drawing.Point(167, 167);
            this.button209.Margin = new System.Windows.Forms.Padding(1);
            this.button209.Name = "button209";
            this.button209.Size = new System.Drawing.Size(30, 30);
            this.button209.TabIndex = 143;
            this.button209.UseVisualStyleBackColor = true;
            // 
            // button208
            // 
            this.button208.Location = new System.Drawing.Point(134, 167);
            this.button208.Margin = new System.Windows.Forms.Padding(1);
            this.button208.Name = "button208";
            this.button208.Size = new System.Drawing.Size(30, 30);
            this.button208.TabIndex = 142;
            this.button208.UseVisualStyleBackColor = true;
            // 
            // button207
            // 
            this.button207.Location = new System.Drawing.Point(101, 167);
            this.button207.Margin = new System.Windows.Forms.Padding(1);
            this.button207.Name = "button207";
            this.button207.Size = new System.Drawing.Size(30, 30);
            this.button207.TabIndex = 141;
            this.button207.UseVisualStyleBackColor = true;
            // 
            // button206
            // 
            this.button206.Location = new System.Drawing.Point(68, 167);
            this.button206.Margin = new System.Windows.Forms.Padding(1);
            this.button206.Name = "button206";
            this.button206.Size = new System.Drawing.Size(30, 30);
            this.button206.TabIndex = 140;
            this.button206.UseVisualStyleBackColor = true;
            // 
            // button205
            // 
            this.button205.Location = new System.Drawing.Point(35, 167);
            this.button205.Margin = new System.Windows.Forms.Padding(1);
            this.button205.Name = "button205";
            this.button205.Size = new System.Drawing.Size(30, 30);
            this.button205.TabIndex = 139;
            this.button205.UseVisualStyleBackColor = true;
            // 
            // button204
            // 
            this.button204.Location = new System.Drawing.Point(2, 167);
            this.button204.Margin = new System.Windows.Forms.Padding(1);
            this.button204.Name = "button204";
            this.button204.Size = new System.Drawing.Size(30, 30);
            this.button204.TabIndex = 138;
            this.button204.UseVisualStyleBackColor = true;
            // 
            // button203
            // 
            this.button203.Location = new System.Drawing.Point(365, 134);
            this.button203.Margin = new System.Windows.Forms.Padding(1);
            this.button203.Name = "button203";
            this.button203.Size = new System.Drawing.Size(30, 30);
            this.button203.TabIndex = 137;
            this.button203.UseVisualStyleBackColor = true;
            // 
            // button202
            // 
            this.button202.Location = new System.Drawing.Point(332, 134);
            this.button202.Margin = new System.Windows.Forms.Padding(1);
            this.button202.Name = "button202";
            this.button202.Size = new System.Drawing.Size(30, 30);
            this.button202.TabIndex = 136;
            this.button202.UseVisualStyleBackColor = true;
            // 
            // button201
            // 
            this.button201.Location = new System.Drawing.Point(299, 134);
            this.button201.Margin = new System.Windows.Forms.Padding(1);
            this.button201.Name = "button201";
            this.button201.Size = new System.Drawing.Size(30, 30);
            this.button201.TabIndex = 135;
            this.button201.UseVisualStyleBackColor = true;
            // 
            // button200
            // 
            this.button200.Location = new System.Drawing.Point(266, 134);
            this.button200.Margin = new System.Windows.Forms.Padding(1);
            this.button200.Name = "button200";
            this.button200.Size = new System.Drawing.Size(30, 30);
            this.button200.TabIndex = 134;
            this.button200.UseVisualStyleBackColor = true;
            // 
            // button199
            // 
            this.button199.Location = new System.Drawing.Point(233, 134);
            this.button199.Margin = new System.Windows.Forms.Padding(1);
            this.button199.Name = "button199";
            this.button199.Size = new System.Drawing.Size(30, 30);
            this.button199.TabIndex = 133;
            this.button199.UseVisualStyleBackColor = true;
            // 
            // button198
            // 
            this.button198.Location = new System.Drawing.Point(200, 134);
            this.button198.Margin = new System.Windows.Forms.Padding(1);
            this.button198.Name = "button198";
            this.button198.Size = new System.Drawing.Size(30, 30);
            this.button198.TabIndex = 132;
            this.button198.UseVisualStyleBackColor = true;
            // 
            // button197
            // 
            this.button197.Location = new System.Drawing.Point(167, 134);
            this.button197.Margin = new System.Windows.Forms.Padding(1);
            this.button197.Name = "button197";
            this.button197.Size = new System.Drawing.Size(30, 30);
            this.button197.TabIndex = 131;
            this.button197.UseVisualStyleBackColor = true;
            // 
            // button196
            // 
            this.button196.Location = new System.Drawing.Point(134, 134);
            this.button196.Margin = new System.Windows.Forms.Padding(1);
            this.button196.Name = "button196";
            this.button196.Size = new System.Drawing.Size(30, 30);
            this.button196.TabIndex = 130;
            this.button196.UseVisualStyleBackColor = true;
            // 
            // button195
            // 
            this.button195.Location = new System.Drawing.Point(101, 134);
            this.button195.Margin = new System.Windows.Forms.Padding(1);
            this.button195.Name = "button195";
            this.button195.Size = new System.Drawing.Size(30, 30);
            this.button195.TabIndex = 129;
            this.button195.UseVisualStyleBackColor = true;
            // 
            // button194
            // 
            this.button194.Location = new System.Drawing.Point(68, 134);
            this.button194.Margin = new System.Windows.Forms.Padding(1);
            this.button194.Name = "button194";
            this.button194.Size = new System.Drawing.Size(30, 30);
            this.button194.TabIndex = 128;
            this.button194.UseVisualStyleBackColor = true;
            // 
            // button193
            // 
            this.button193.Location = new System.Drawing.Point(35, 134);
            this.button193.Margin = new System.Windows.Forms.Padding(1);
            this.button193.Name = "button193";
            this.button193.Size = new System.Drawing.Size(30, 30);
            this.button193.TabIndex = 127;
            this.button193.UseVisualStyleBackColor = true;
            // 
            // button192
            // 
            this.button192.Location = new System.Drawing.Point(2, 134);
            this.button192.Margin = new System.Windows.Forms.Padding(1);
            this.button192.Name = "button192";
            this.button192.Size = new System.Drawing.Size(30, 30);
            this.button192.TabIndex = 126;
            this.button192.UseVisualStyleBackColor = true;
            // 
            // button191
            // 
            this.button191.Location = new System.Drawing.Point(365, 101);
            this.button191.Margin = new System.Windows.Forms.Padding(1);
            this.button191.Name = "button191";
            this.button191.Size = new System.Drawing.Size(30, 30);
            this.button191.TabIndex = 125;
            this.button191.UseVisualStyleBackColor = true;
            // 
            // button190
            // 
            this.button190.Location = new System.Drawing.Point(332, 101);
            this.button190.Margin = new System.Windows.Forms.Padding(1);
            this.button190.Name = "button190";
            this.button190.Size = new System.Drawing.Size(30, 30);
            this.button190.TabIndex = 124;
            this.button190.UseVisualStyleBackColor = true;
            // 
            // button189
            // 
            this.button189.Location = new System.Drawing.Point(299, 101);
            this.button189.Margin = new System.Windows.Forms.Padding(1);
            this.button189.Name = "button189";
            this.button189.Size = new System.Drawing.Size(30, 30);
            this.button189.TabIndex = 123;
            this.button189.UseVisualStyleBackColor = true;
            // 
            // button188
            // 
            this.button188.Location = new System.Drawing.Point(266, 101);
            this.button188.Margin = new System.Windows.Forms.Padding(1);
            this.button188.Name = "button188";
            this.button188.Size = new System.Drawing.Size(30, 30);
            this.button188.TabIndex = 122;
            this.button188.UseVisualStyleBackColor = true;
            // 
            // button187
            // 
            this.button187.Location = new System.Drawing.Point(233, 101);
            this.button187.Margin = new System.Windows.Forms.Padding(1);
            this.button187.Name = "button187";
            this.button187.Size = new System.Drawing.Size(30, 30);
            this.button187.TabIndex = 121;
            this.button187.UseVisualStyleBackColor = true;
            // 
            // button186
            // 
            this.button186.Location = new System.Drawing.Point(200, 101);
            this.button186.Margin = new System.Windows.Forms.Padding(1);
            this.button186.Name = "button186";
            this.button186.Size = new System.Drawing.Size(30, 30);
            this.button186.TabIndex = 120;
            this.button186.UseVisualStyleBackColor = true;
            // 
            // button185
            // 
            this.button185.Location = new System.Drawing.Point(167, 101);
            this.button185.Margin = new System.Windows.Forms.Padding(1);
            this.button185.Name = "button185";
            this.button185.Size = new System.Drawing.Size(30, 30);
            this.button185.TabIndex = 119;
            this.button185.UseVisualStyleBackColor = true;
            // 
            // button184
            // 
            this.button184.Location = new System.Drawing.Point(134, 101);
            this.button184.Margin = new System.Windows.Forms.Padding(1);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(30, 30);
            this.button184.TabIndex = 118;
            this.button184.UseVisualStyleBackColor = true;
            // 
            // button183
            // 
            this.button183.Location = new System.Drawing.Point(101, 101);
            this.button183.Margin = new System.Windows.Forms.Padding(1);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(30, 30);
            this.button183.TabIndex = 117;
            this.button183.UseVisualStyleBackColor = true;
            // 
            // button182
            // 
            this.button182.Location = new System.Drawing.Point(68, 101);
            this.button182.Margin = new System.Windows.Forms.Padding(1);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(30, 30);
            this.button182.TabIndex = 116;
            this.button182.UseVisualStyleBackColor = true;
            // 
            // button181
            // 
            this.button181.Location = new System.Drawing.Point(35, 101);
            this.button181.Margin = new System.Windows.Forms.Padding(1);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(30, 30);
            this.button181.TabIndex = 115;
            this.button181.UseVisualStyleBackColor = true;
            // 
            // button180
            // 
            this.button180.Location = new System.Drawing.Point(2, 101);
            this.button180.Margin = new System.Windows.Forms.Padding(1);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(30, 30);
            this.button180.TabIndex = 114;
            this.button180.UseVisualStyleBackColor = true;
            // 
            // button179
            // 
            this.button179.Location = new System.Drawing.Point(365, 68);
            this.button179.Margin = new System.Windows.Forms.Padding(1);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(30, 30);
            this.button179.TabIndex = 113;
            this.button179.UseVisualStyleBackColor = true;
            // 
            // button178
            // 
            this.button178.Location = new System.Drawing.Point(332, 68);
            this.button178.Margin = new System.Windows.Forms.Padding(1);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(30, 30);
            this.button178.TabIndex = 112;
            this.button178.UseVisualStyleBackColor = true;
            // 
            // button177
            // 
            this.button177.Location = new System.Drawing.Point(299, 68);
            this.button177.Margin = new System.Windows.Forms.Padding(1);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(30, 30);
            this.button177.TabIndex = 111;
            this.button177.UseVisualStyleBackColor = true;
            // 
            // button176
            // 
            this.button176.Location = new System.Drawing.Point(266, 68);
            this.button176.Margin = new System.Windows.Forms.Padding(1);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(30, 30);
            this.button176.TabIndex = 110;
            this.button176.UseVisualStyleBackColor = true;
            // 
            // button175
            // 
            this.button175.Location = new System.Drawing.Point(233, 68);
            this.button175.Margin = new System.Windows.Forms.Padding(1);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(30, 30);
            this.button175.TabIndex = 109;
            this.button175.UseVisualStyleBackColor = true;
            // 
            // button174
            // 
            this.button174.Location = new System.Drawing.Point(200, 68);
            this.button174.Margin = new System.Windows.Forms.Padding(1);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(30, 30);
            this.button174.TabIndex = 108;
            this.button174.UseVisualStyleBackColor = true;
            // 
            // button173
            // 
            this.button173.Location = new System.Drawing.Point(167, 68);
            this.button173.Margin = new System.Windows.Forms.Padding(1);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(30, 30);
            this.button173.TabIndex = 107;
            this.button173.UseVisualStyleBackColor = true;
            // 
            // button172
            // 
            this.button172.Location = new System.Drawing.Point(134, 68);
            this.button172.Margin = new System.Windows.Forms.Padding(1);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(30, 30);
            this.button172.TabIndex = 106;
            this.button172.UseVisualStyleBackColor = true;
            // 
            // button171
            // 
            this.button171.Location = new System.Drawing.Point(101, 68);
            this.button171.Margin = new System.Windows.Forms.Padding(1);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(30, 30);
            this.button171.TabIndex = 105;
            this.button171.UseVisualStyleBackColor = true;
            // 
            // button170
            // 
            this.button170.Location = new System.Drawing.Point(68, 68);
            this.button170.Margin = new System.Windows.Forms.Padding(1);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(30, 30);
            this.button170.TabIndex = 104;
            this.button170.UseVisualStyleBackColor = true;
            // 
            // button169
            // 
            this.button169.Location = new System.Drawing.Point(35, 68);
            this.button169.Margin = new System.Windows.Forms.Padding(1);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(30, 30);
            this.button169.TabIndex = 103;
            this.button169.UseVisualStyleBackColor = true;
            // 
            // button168
            // 
            this.button168.Location = new System.Drawing.Point(2, 68);
            this.button168.Margin = new System.Windows.Forms.Padding(1);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(30, 30);
            this.button168.TabIndex = 102;
            this.button168.UseVisualStyleBackColor = true;
            // 
            // button167
            // 
            this.button167.Location = new System.Drawing.Point(365, 35);
            this.button167.Margin = new System.Windows.Forms.Padding(1);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(30, 30);
            this.button167.TabIndex = 101;
            this.button167.UseVisualStyleBackColor = true;
            // 
            // button166
            // 
            this.button166.Location = new System.Drawing.Point(332, 35);
            this.button166.Margin = new System.Windows.Forms.Padding(1);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(30, 30);
            this.button166.TabIndex = 100;
            this.button166.UseVisualStyleBackColor = true;
            // 
            // button165
            // 
            this.button165.Location = new System.Drawing.Point(299, 35);
            this.button165.Margin = new System.Windows.Forms.Padding(1);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(30, 30);
            this.button165.TabIndex = 99;
            this.button165.UseVisualStyleBackColor = true;
            // 
            // button164
            // 
            this.button164.Location = new System.Drawing.Point(266, 35);
            this.button164.Margin = new System.Windows.Forms.Padding(1);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(30, 30);
            this.button164.TabIndex = 98;
            this.button164.UseVisualStyleBackColor = true;
            // 
            // button163
            // 
            this.button163.Location = new System.Drawing.Point(233, 35);
            this.button163.Margin = new System.Windows.Forms.Padding(1);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(30, 30);
            this.button163.TabIndex = 97;
            this.button163.UseVisualStyleBackColor = true;
            // 
            // button162
            // 
            this.button162.Location = new System.Drawing.Point(200, 35);
            this.button162.Margin = new System.Windows.Forms.Padding(1);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(30, 30);
            this.button162.TabIndex = 96;
            this.button162.UseVisualStyleBackColor = true;
            // 
            // button161
            // 
            this.button161.Location = new System.Drawing.Point(167, 35);
            this.button161.Margin = new System.Windows.Forms.Padding(1);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(30, 30);
            this.button161.TabIndex = 95;
            this.button161.UseVisualStyleBackColor = true;
            // 
            // button160
            // 
            this.button160.Location = new System.Drawing.Point(134, 35);
            this.button160.Margin = new System.Windows.Forms.Padding(1);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(30, 30);
            this.button160.TabIndex = 94;
            this.button160.UseVisualStyleBackColor = true;
            // 
            // button159
            // 
            this.button159.Location = new System.Drawing.Point(101, 35);
            this.button159.Margin = new System.Windows.Forms.Padding(1);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(30, 30);
            this.button159.TabIndex = 93;
            this.button159.UseVisualStyleBackColor = true;
            // 
            // button158
            // 
            this.button158.Location = new System.Drawing.Point(68, 35);
            this.button158.Margin = new System.Windows.Forms.Padding(1);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(30, 30);
            this.button158.TabIndex = 92;
            this.button158.UseVisualStyleBackColor = true;
            // 
            // button157
            // 
            this.button157.Location = new System.Drawing.Point(35, 35);
            this.button157.Margin = new System.Windows.Forms.Padding(1);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(30, 30);
            this.button157.TabIndex = 91;
            this.button157.UseVisualStyleBackColor = true;
            // 
            // button156
            // 
            this.button156.Location = new System.Drawing.Point(2, 35);
            this.button156.Margin = new System.Windows.Forms.Padding(1);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(30, 30);
            this.button156.TabIndex = 90;
            this.button156.UseVisualStyleBackColor = true;
            // 
            // button155
            // 
            this.button155.Location = new System.Drawing.Point(365, 2);
            this.button155.Margin = new System.Windows.Forms.Padding(1);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(30, 30);
            this.button155.TabIndex = 89;
            this.button155.UseVisualStyleBackColor = true;
            // 
            // button154
            // 
            this.button154.Location = new System.Drawing.Point(332, 2);
            this.button154.Margin = new System.Windows.Forms.Padding(1);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(30, 30);
            this.button154.TabIndex = 88;
            this.button154.UseVisualStyleBackColor = true;
            // 
            // button153
            // 
            this.button153.Location = new System.Drawing.Point(299, 2);
            this.button153.Margin = new System.Windows.Forms.Padding(1);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(30, 30);
            this.button153.TabIndex = 87;
            this.button153.UseVisualStyleBackColor = true;
            // 
            // button152
            // 
            this.button152.Location = new System.Drawing.Point(266, 2);
            this.button152.Margin = new System.Windows.Forms.Padding(1);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(30, 30);
            this.button152.TabIndex = 86;
            this.button152.UseVisualStyleBackColor = true;
            // 
            // button151
            // 
            this.button151.Location = new System.Drawing.Point(233, 2);
            this.button151.Margin = new System.Windows.Forms.Padding(1);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(30, 30);
            this.button151.TabIndex = 85;
            this.button151.UseVisualStyleBackColor = true;
            // 
            // button150
            // 
            this.button150.Location = new System.Drawing.Point(200, 2);
            this.button150.Margin = new System.Windows.Forms.Padding(1);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(30, 30);
            this.button150.TabIndex = 84;
            this.button150.UseVisualStyleBackColor = true;
            // 
            // button216
            // 
            this.button216.Location = new System.Drawing.Point(167, 2);
            this.button216.Margin = new System.Windows.Forms.Padding(1);
            this.button216.Name = "button216";
            this.button216.Size = new System.Drawing.Size(30, 30);
            this.button216.TabIndex = 83;
            this.button216.UseVisualStyleBackColor = true;
            // 
            // button149
            // 
            this.button149.Location = new System.Drawing.Point(134, 2);
            this.button149.Margin = new System.Windows.Forms.Padding(1);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(30, 30);
            this.button149.TabIndex = 82;
            this.button149.UseVisualStyleBackColor = true;
            // 
            // button148
            // 
            this.button148.Location = new System.Drawing.Point(68, 2);
            this.button148.Margin = new System.Windows.Forms.Padding(1);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(30, 30);
            this.button148.TabIndex = 81;
            this.button148.UseVisualStyleBackColor = true;
            // 
            // button147
            // 
            this.button147.Location = new System.Drawing.Point(101, 2);
            this.button147.Margin = new System.Windows.Forms.Padding(1);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(30, 30);
            this.button147.TabIndex = 80;
            this.button147.UseVisualStyleBackColor = true;
            // 
            // button146
            // 
            this.button146.Location = new System.Drawing.Point(35, 2);
            this.button146.Margin = new System.Windows.Forms.Padding(1);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(30, 30);
            this.button146.TabIndex = 79;
            this.button146.UseVisualStyleBackColor = true;
            // 
            // button145
            // 
            this.button145.Location = new System.Drawing.Point(2, 2);
            this.button145.Margin = new System.Windows.Forms.Padding(1);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(30, 30);
            this.button145.TabIndex = 78;
            this.button145.UseVisualStyleBackColor = true;
            // 
            // btnNewGame
            // 
            this.btnNewGame.Location = new System.Drawing.Point(440, 595);
            this.btnNewGame.Name = "btnNewGame";
            this.btnNewGame.Size = new System.Drawing.Size(119, 34);
            this.btnNewGame.TabIndex = 2;
            this.btnNewGame.Text = "New Game";
            this.btnNewGame.UseVisualStyleBackColor = true;
            this.btnNewGame.Click += new System.EventHandler(this.btnNewGame_Click);
            // 
            // rbVertical
            // 
            this.rbVertical.AutoSize = true;
            this.rbVertical.Location = new System.Drawing.Point(16, 19);
            this.rbVertical.Name = "rbVertical";
            this.rbVertical.Size = new System.Drawing.Size(60, 17);
            this.rbVertical.TabIndex = 3;
            this.rbVertical.TabStop = true;
            this.rbVertical.Text = "Vertical";
            this.rbVertical.UseVisualStyleBackColor = true;
            this.rbVertical.CheckedChanged += new System.EventHandler(this.rbVertical_Checked);
            // 
            // groupBoxPlayerAlignment
            // 
            this.groupBoxPlayerAlignment.Controls.Add(this.rbHorizontal);
            this.groupBoxPlayerAlignment.Controls.Add(this.rbVertical);
            this.groupBoxPlayerAlignment.Location = new System.Drawing.Point(111, 588);
            this.groupBoxPlayerAlignment.Name = "groupBoxPlayerAlignment";
            this.groupBoxPlayerAlignment.Size = new System.Drawing.Size(142, 71);
            this.groupBoxPlayerAlignment.TabIndex = 4;
            this.groupBoxPlayerAlignment.TabStop = false;
            this.groupBoxPlayerAlignment.Text = "Player Alignment";
            // 
            // rbHorizontal
            // 
            this.rbHorizontal.AutoSize = true;
            this.rbHorizontal.Location = new System.Drawing.Point(16, 42);
            this.rbHorizontal.Name = "rbHorizontal";
            this.rbHorizontal.Size = new System.Drawing.Size(72, 17);
            this.rbHorizontal.TabIndex = 4;
            this.rbHorizontal.TabStop = true;
            this.rbHorizontal.Text = "Horizontal";
            this.rbHorizontal.UseVisualStyleBackColor = true;
            this.rbHorizontal.CheckedChanged += new System.EventHandler(this.rbHorizontal_Checked);
            // 
            // groupBoxPlayerShips
            // 
            this.groupBoxPlayerShips.Controls.Add(this.rbSubmarine);
            this.groupBoxPlayerShips.Controls.Add(this.rbPTBoat);
            this.groupBoxPlayerShips.Controls.Add(this.rbCarrier);
            this.groupBoxPlayerShips.Controls.Add(this.rbBattleship);
            this.groupBoxPlayerShips.Controls.Add(this.rbCruiser);
            this.groupBoxPlayerShips.Location = new System.Drawing.Point(259, 588);
            this.groupBoxPlayerShips.Name = "groupBoxPlayerShips";
            this.groupBoxPlayerShips.Size = new System.Drawing.Size(102, 136);
            this.groupBoxPlayerShips.TabIndex = 5;
            this.groupBoxPlayerShips.TabStop = false;
            this.groupBoxPlayerShips.Text = "Player Ships";
            // 
            // rbSubmarine
            // 
            this.rbSubmarine.AutoSize = true;
            this.rbSubmarine.Location = new System.Drawing.Point(6, 64);
            this.rbSubmarine.Name = "rbSubmarine";
            this.rbSubmarine.Size = new System.Drawing.Size(75, 17);
            this.rbSubmarine.TabIndex = 3;
            this.rbSubmarine.TabStop = true;
            this.rbSubmarine.Text = "Submarine";
            this.rbSubmarine.UseVisualStyleBackColor = true;
            this.rbSubmarine.CheckedChanged += new System.EventHandler(this.rbSubmarine_Checked);
            // 
            // rbPTBoat
            // 
            this.rbPTBoat.AutoSize = true;
            this.rbPTBoat.Location = new System.Drawing.Point(6, 19);
            this.rbPTBoat.Name = "rbPTBoat";
            this.rbPTBoat.Size = new System.Drawing.Size(64, 17);
            this.rbPTBoat.TabIndex = 2;
            this.rbPTBoat.TabStop = true;
            this.rbPTBoat.Text = "PT Boat";
            this.rbPTBoat.UseVisualStyleBackColor = true;
            this.rbPTBoat.CheckedChanged += new System.EventHandler(this.rbPTBoat_Checked);
            // 
            // rbCarrier
            // 
            this.rbCarrier.AutoSize = true;
            this.rbCarrier.Location = new System.Drawing.Point(6, 108);
            this.rbCarrier.Name = "rbCarrier";
            this.rbCarrier.Size = new System.Drawing.Size(55, 17);
            this.rbCarrier.TabIndex = 1;
            this.rbCarrier.TabStop = true;
            this.rbCarrier.Text = "Carrier";
            this.rbCarrier.UseVisualStyleBackColor = true;
            this.rbCarrier.CheckedChanged += new System.EventHandler(this.rbCarrier_Checked);
            // 
            // rbBattleship
            // 
            this.rbBattleship.AutoSize = true;
            this.rbBattleship.Location = new System.Drawing.Point(6, 85);
            this.rbBattleship.Name = "rbBattleship";
            this.rbBattleship.Size = new System.Drawing.Size(71, 17);
            this.rbBattleship.TabIndex = 0;
            this.rbBattleship.TabStop = true;
            this.rbBattleship.Text = "Battleship";
            this.rbBattleship.UseVisualStyleBackColor = true;
            this.rbBattleship.CheckedChanged += new System.EventHandler(this.rbBattleship_Checked);
            // 
            // rbCruiser
            // 
            this.rbCruiser.AutoSize = true;
            this.rbCruiser.Location = new System.Drawing.Point(6, 42);
            this.rbCruiser.Name = "rbCruiser";
            this.rbCruiser.Size = new System.Drawing.Size(57, 17);
            this.rbCruiser.TabIndex = 2;
            this.rbCruiser.TabStop = true;
            this.rbCruiser.Text = "Cruiser";
            this.rbCruiser.UseVisualStyleBackColor = true;
            this.rbCruiser.CheckedChanged += new System.EventHandler(this.rbCruiser_Checked);
            // 
            // btnReady
            // 
            this.btnReady.Location = new System.Drawing.Point(148, 670);
            this.btnReady.Name = "btnReady";
            this.btnReady.Size = new System.Drawing.Size(75, 23);
            this.btnReady.TabIndex = 7;
            this.btnReady.Text = "Ready";
            this.btnReady.UseVisualStyleBackColor = true;
            this.btnReady.Click += new System.EventHandler(this.btnReady_Click);
            // 
            // btnSurrender
            // 
            this.btnSurrender.Location = new System.Drawing.Point(440, 643);
            this.btnSurrender.Name = "btnSurrender";
            this.btnSurrender.Size = new System.Drawing.Size(119, 34);
            this.btnSurrender.TabIndex = 8;
            this.btnSurrender.Text = "Surrender";
            this.btnSurrender.UseVisualStyleBackColor = true;
            this.btnSurrender.Click += new System.EventHandler(this.btnSurrender_Click);
            // 
            // lblTurnCounter
            // 
            this.lblTurnCounter.AutoSize = true;
            this.lblTurnCounter.Location = new System.Drawing.Point(707, 595);
            this.lblTurnCounter.Name = "lblTurnCounter";
            this.lblTurnCounter.Size = new System.Drawing.Size(66, 13);
            this.lblTurnCounter.TabIndex = 9;
            this.lblTurnCounter.Text = "TurnCounter";
            // 
            // lblCounter
            // 
            this.lblCounter.AutoSize = true;
            this.lblCounter.Location = new System.Drawing.Point(632, 595);
            this.lblCounter.Name = "lblCounter";
            this.lblCounter.Size = new System.Drawing.Size(72, 13);
            this.lblCounter.TabIndex = 10;
            this.lblCounter.Text = "Turn Counter:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 20);
            this.label1.TabIndex = 16;
            this.label1.Text = "A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(41, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 20);
            this.label2.TabIndex = 17;
            this.label2.Text = "B";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(41, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 20);
            this.label3.TabIndex = 18;
            this.label3.Text = "C";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(41, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 20);
            this.label4.TabIndex = 19;
            this.label4.Text = "D";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(41, 236);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 20);
            this.label5.TabIndex = 20;
            this.label5.Text = "E";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(41, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 20);
            this.label6.TabIndex = 21;
            this.label6.Text = "F";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(41, 302);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 20);
            this.label7.TabIndex = 22;
            this.label7.Text = "G";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(41, 335);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 20);
            this.label8.TabIndex = 23;
            this.label8.Text = "H";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(41, 368);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 20);
            this.label9.TabIndex = 24;
            this.label9.Text = "I";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(41, 401);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(18, 20);
            this.label10.TabIndex = 25;
            this.label10.Text = "J";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(41, 434);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 20);
            this.label11.TabIndex = 26;
            this.label11.Text = "K";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(41, 467);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(19, 20);
            this.label12.TabIndex = 27;
            this.label12.Text = "L";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(507, 104);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(21, 20);
            this.label13.TabIndex = 28;
            this.label13.Text = "A";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(507, 137);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(21, 20);
            this.label14.TabIndex = 29;
            this.label14.Text = "B";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(507, 170);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(21, 20);
            this.label15.TabIndex = 30;
            this.label15.Text = "C";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(507, 203);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(22, 20);
            this.label16.TabIndex = 31;
            this.label16.Text = "D";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(507, 236);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 20);
            this.label17.TabIndex = 32;
            this.label17.Text = "E";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(507, 269);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(20, 20);
            this.label18.TabIndex = 33;
            this.label18.Text = "F";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(507, 302);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(23, 20);
            this.label19.TabIndex = 34;
            this.label19.Text = "G";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(507, 335);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(22, 20);
            this.label20.TabIndex = 35;
            this.label20.Text = "H";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(507, 368);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(15, 20);
            this.label21.TabIndex = 36;
            this.label21.Text = "I";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(507, 401);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(18, 20);
            this.label22.TabIndex = 37;
            this.label22.Text = "J";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(505, 434);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(20, 20);
            this.label23.TabIndex = 38;
            this.label23.Text = "K";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(507, 467);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(19, 20);
            this.label24.TabIndex = 39;
            this.label24.Text = "L";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(74, 71);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(19, 20);
            this.label25.TabIndex = 40;
            this.label25.Text = "1";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(107, 71);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(19, 20);
            this.label26.TabIndex = 41;
            this.label26.Text = "2";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(140, 71);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(19, 20);
            this.label27.TabIndex = 42;
            this.label27.Text = "3";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(173, 71);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(19, 20);
            this.label28.TabIndex = 43;
            this.label28.Text = "4";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(207, 71);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(19, 20);
            this.label29.TabIndex = 44;
            this.label29.Text = "5";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(240, 71);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(19, 20);
            this.label30.TabIndex = 45;
            this.label30.Text = "6";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(272, 71);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(19, 20);
            this.label31.TabIndex = 46;
            this.label31.Text = "7";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(306, 71);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(19, 20);
            this.label32.TabIndex = 47;
            this.label32.Text = "8";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(432, 71);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(29, 20);
            this.label33.TabIndex = 48;
            this.label33.Text = "12";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(400, 71);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(29, 20);
            this.label34.TabIndex = 49;
            this.label34.Text = "11";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(367, 71);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(29, 20);
            this.label35.TabIndex = 50;
            this.label35.Text = "10";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(338, 71);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(19, 20);
            this.label36.TabIndex = 51;
            this.label36.Text = "9";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(540, 71);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(19, 20);
            this.label37.TabIndex = 52;
            this.label37.Text = "1";
            this.label37.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(573, 71);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(19, 20);
            this.label38.TabIndex = 53;
            this.label38.Text = "2";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(607, 71);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(19, 20);
            this.label39.TabIndex = 54;
            this.label39.Text = "3";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(639, 71);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(19, 20);
            this.label40.TabIndex = 55;
            this.label40.Text = "4";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(673, 71);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(19, 20);
            this.label41.TabIndex = 56;
            this.label41.Text = "5";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(706, 71);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(19, 20);
            this.label42.TabIndex = 57;
            this.label42.Text = "6";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(738, 71);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(19, 20);
            this.label43.TabIndex = 58;
            this.label43.Text = "7";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(772, 71);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(19, 20);
            this.label44.TabIndex = 59;
            this.label44.Text = "8";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(804, 71);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(19, 20);
            this.label45.TabIndex = 60;
            this.label45.Text = "9";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(831, 71);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(29, 20);
            this.label46.TabIndex = 61;
            this.label46.Text = "10";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(865, 71);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(29, 20);
            this.label47.TabIndex = 62;
            this.label47.Text = "11";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(898, 71);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(29, 20);
            this.label48.TabIndex = 63;
            this.label48.Text = "12";
            // 
            // lblHumanCoordinates
            // 
            this.lblHumanCoordinates.AutoSize = true;
            this.lblHumanCoordinates.Location = new System.Drawing.Point(749, 620);
            this.lblHumanCoordinates.Name = "lblHumanCoordinates";
            this.lblHumanCoordinates.Size = new System.Drawing.Size(97, 13);
            this.lblHumanCoordinates.TabIndex = 69;
            this.lblHumanCoordinates.Text = "HumanCoordinates";
            // 
            // lblCPUCoordinate
            // 
            this.lblCPUCoordinate.AutoSize = true;
            this.lblCPUCoordinate.Location = new System.Drawing.Point(749, 641);
            this.lblCPUCoordinate.Name = "lblCPUCoordinate";
            this.lblCPUCoordinate.Size = new System.Drawing.Size(85, 13);
            this.lblCPUCoordinate.TabIndex = 70;
            this.lblCPUCoordinate.Text = "CPUCoordinates";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(632, 620);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(98, 13);
            this.label49.TabIndex = 71;
            this.label49.Text = "Player Coordinates:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(632, 641);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(91, 13);
            this.label50.TabIndex = 72;
            this.label50.Text = "CPU Coordinates:";
            // 
            // pbHeader
            // 
            this.pbHeader.Location = new System.Drawing.Point(323, 12);
            this.pbHeader.Name = "pbHeader";
            this.pbHeader.Size = new System.Drawing.Size(498, 43);
            this.pbHeader.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbHeader.TabIndex = 73;
            this.pbHeader.TabStop = false;
            // 
            // pbCPUCarrier
            // 
            this.pbCPUCarrier.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbCPUCarrier.Location = new System.Drawing.Point(833, 504);
            this.pbCPUCarrier.Name = "pbCPUCarrier";
            this.pbCPUCarrier.Size = new System.Drawing.Size(55, 65);
            this.pbCPUCarrier.TabIndex = 68;
            this.pbCPUCarrier.TabStop = false;
            // 
            // pbCPUBattleship
            // 
            this.pbCPUBattleship.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbCPUBattleship.Location = new System.Drawing.Point(766, 504);
            this.pbCPUBattleship.Name = "pbCPUBattleship";
            this.pbCPUBattleship.Size = new System.Drawing.Size(55, 65);
            this.pbCPUBattleship.TabIndex = 67;
            this.pbCPUBattleship.TabStop = false;
            // 
            // pbCPUSub
            // 
            this.pbCPUSub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbCPUSub.Location = new System.Drawing.Point(699, 504);
            this.pbCPUSub.Name = "pbCPUSub";
            this.pbCPUSub.Size = new System.Drawing.Size(55, 65);
            this.pbCPUSub.TabIndex = 66;
            this.pbCPUSub.TabStop = false;
            // 
            // pbCPUCruiser
            // 
            this.pbCPUCruiser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbCPUCruiser.Location = new System.Drawing.Point(632, 504);
            this.pbCPUCruiser.Name = "pbCPUCruiser";
            this.pbCPUCruiser.Size = new System.Drawing.Size(55, 65);
            this.pbCPUCruiser.TabIndex = 65;
            this.pbCPUCruiser.TabStop = false;
            // 
            // pbCPUPtBoat
            // 
            this.pbCPUPtBoat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbCPUPtBoat.Location = new System.Drawing.Point(564, 504);
            this.pbCPUPtBoat.Name = "pbCPUPtBoat";
            this.pbCPUPtBoat.Size = new System.Drawing.Size(55, 65);
            this.pbCPUPtBoat.TabIndex = 64;
            this.pbCPUPtBoat.TabStop = false;
            // 
            // pbHumanCarrier
            // 
            this.pbHumanCarrier.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbHumanCarrier.Location = new System.Drawing.Point(367, 504);
            this.pbHumanCarrier.Name = "pbHumanCarrier";
            this.pbHumanCarrier.Size = new System.Drawing.Size(55, 65);
            this.pbHumanCarrier.TabIndex = 15;
            this.pbHumanCarrier.TabStop = false;
            // 
            // pbHumanBattleship
            // 
            this.pbHumanBattleship.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbHumanBattleship.Location = new System.Drawing.Point(300, 504);
            this.pbHumanBattleship.Name = "pbHumanBattleship";
            this.pbHumanBattleship.Size = new System.Drawing.Size(55, 65);
            this.pbHumanBattleship.TabIndex = 14;
            this.pbHumanBattleship.TabStop = false;
            // 
            // pbHumanSub
            // 
            this.pbHumanSub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbHumanSub.Location = new System.Drawing.Point(233, 504);
            this.pbHumanSub.Name = "pbHumanSub";
            this.pbHumanSub.Size = new System.Drawing.Size(55, 65);
            this.pbHumanSub.TabIndex = 13;
            this.pbHumanSub.TabStop = false;
            // 
            // pbHumanCruiser
            // 
            this.pbHumanCruiser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbHumanCruiser.Location = new System.Drawing.Point(165, 504);
            this.pbHumanCruiser.Name = "pbHumanCruiser";
            this.pbHumanCruiser.Size = new System.Drawing.Size(55, 65);
            this.pbHumanCruiser.TabIndex = 12;
            this.pbHumanCruiser.TabStop = false;
            // 
            // pbHumanPTBoat
            // 
            this.pbHumanPTBoat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbHumanPTBoat.Location = new System.Drawing.Point(98, 504);
            this.pbHumanPTBoat.Name = "pbHumanPTBoat";
            this.pbHumanPTBoat.Size = new System.Drawing.Size(55, 65);
            this.pbHumanPTBoat.TabIndex = 11;
            this.pbHumanPTBoat.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(983, 733);
            this.Controls.Add(this.pbHeader);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.lblCPUCoordinate);
            this.Controls.Add(this.lblHumanCoordinates);
            this.Controls.Add(this.pbCPUCarrier);
            this.Controls.Add(this.pbCPUBattleship);
            this.Controls.Add(this.pbCPUSub);
            this.Controls.Add(this.pbCPUCruiser);
            this.Controls.Add(this.pbCPUPtBoat);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbHumanCarrier);
            this.Controls.Add(this.pbHumanBattleship);
            this.Controls.Add(this.pbHumanSub);
            this.Controls.Add(this.pbHumanCruiser);
            this.Controls.Add(this.pbHumanPTBoat);
            this.Controls.Add(this.lblCounter);
            this.Controls.Add(this.lblTurnCounter);
            this.Controls.Add(this.btnSurrender);
            this.Controls.Add(this.btnReady);
            this.Controls.Add(this.groupBoxPlayerShips);
            this.Controls.Add(this.groupBoxPlayerAlignment);
            this.Controls.Add(this.btnNewGame);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBoxPlayerAlignment.ResumeLayout(false);
            this.groupBoxPlayerAlignment.PerformLayout();
            this.groupBoxPlayerShips.ResumeLayout(false);
            this.groupBoxPlayerShips.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeader)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCPUCarrier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCPUBattleship)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCPUSub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCPUCruiser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCPUPtBoat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHumanCarrier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHumanBattleship)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHumanSub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHumanCruiser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHumanPTBoat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.Button button287;
        private System.Windows.Forms.Button button286;
        private System.Windows.Forms.Button button285;
        private System.Windows.Forms.Button button284;
        private System.Windows.Forms.Button button283;
        private System.Windows.Forms.Button button282;
        private System.Windows.Forms.Button button281;
        private System.Windows.Forms.Button button280;
        private System.Windows.Forms.Button button279;
        private System.Windows.Forms.Button button278;
        private System.Windows.Forms.Button button277;
        private System.Windows.Forms.Button button276;
        private System.Windows.Forms.Button button275;
        private System.Windows.Forms.Button button274;
        private System.Windows.Forms.Button button273;
        private System.Windows.Forms.Button button272;
        private System.Windows.Forms.Button button271;
        private System.Windows.Forms.Button button270;
        private System.Windows.Forms.Button button269;
        private System.Windows.Forms.Button button268;
        private System.Windows.Forms.Button button267;
        private System.Windows.Forms.Button button266;
        private System.Windows.Forms.Button button265;
        private System.Windows.Forms.Button button264;
        private System.Windows.Forms.Button button263;
        private System.Windows.Forms.Button button262;
        private System.Windows.Forms.Button button261;
        private System.Windows.Forms.Button button260;
        private System.Windows.Forms.Button button259;
        private System.Windows.Forms.Button button258;
        private System.Windows.Forms.Button button257;
        private System.Windows.Forms.Button button256;
        private System.Windows.Forms.Button button255;
        private System.Windows.Forms.Button button254;
        private System.Windows.Forms.Button button253;
        private System.Windows.Forms.Button button252;
        private System.Windows.Forms.Button button251;
        private System.Windows.Forms.Button button250;
        private System.Windows.Forms.Button button249;
        private System.Windows.Forms.Button button248;
        private System.Windows.Forms.Button button247;
        private System.Windows.Forms.Button button246;
        private System.Windows.Forms.Button button245;
        private System.Windows.Forms.Button button244;
        private System.Windows.Forms.Button button243;
        private System.Windows.Forms.Button button242;
        private System.Windows.Forms.Button button241;
        private System.Windows.Forms.Button button240;
        private System.Windows.Forms.Button button239;
        private System.Windows.Forms.Button button238;
        private System.Windows.Forms.Button button237;
        private System.Windows.Forms.Button button236;
        private System.Windows.Forms.Button button235;
        private System.Windows.Forms.Button button234;
        private System.Windows.Forms.Button button233;
        private System.Windows.Forms.Button button232;
        private System.Windows.Forms.Button button231;
        private System.Windows.Forms.Button button230;
        private System.Windows.Forms.Button button229;
        private System.Windows.Forms.Button button228;
        private System.Windows.Forms.Button button227;
        private System.Windows.Forms.Button button226;
        private System.Windows.Forms.Button button225;
        private System.Windows.Forms.Button button224;
        private System.Windows.Forms.Button button223;
        private System.Windows.Forms.Button button222;
        private System.Windows.Forms.Button button221;
        private System.Windows.Forms.Button button220;
        private System.Windows.Forms.Button button219;
        private System.Windows.Forms.Button button218;
        private System.Windows.Forms.Button button217;
        private System.Windows.Forms.Button button215;
        private System.Windows.Forms.Button button214;
        private System.Windows.Forms.Button button213;
        private System.Windows.Forms.Button button212;
        private System.Windows.Forms.Button button211;
        private System.Windows.Forms.Button button210;
        private System.Windows.Forms.Button button209;
        private System.Windows.Forms.Button button208;
        private System.Windows.Forms.Button button207;
        private System.Windows.Forms.Button button206;
        private System.Windows.Forms.Button button205;
        private System.Windows.Forms.Button button204;
        private System.Windows.Forms.Button button203;
        private System.Windows.Forms.Button button202;
        private System.Windows.Forms.Button button201;
        private System.Windows.Forms.Button button200;
        private System.Windows.Forms.Button button199;
        private System.Windows.Forms.Button button198;
        private System.Windows.Forms.Button button197;
        private System.Windows.Forms.Button button196;
        private System.Windows.Forms.Button button195;
        private System.Windows.Forms.Button button194;
        private System.Windows.Forms.Button button193;
        private System.Windows.Forms.Button button192;
        private System.Windows.Forms.Button button191;
        private System.Windows.Forms.Button button190;
        private System.Windows.Forms.Button button189;
        private System.Windows.Forms.Button button188;
        private System.Windows.Forms.Button button187;
        private System.Windows.Forms.Button button186;
        private System.Windows.Forms.Button button185;
        private System.Windows.Forms.Button button184;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button216;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button288;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.RadioButton rbVertical;
        private System.Windows.Forms.GroupBox groupBoxPlayerAlignment;
        private System.Windows.Forms.RadioButton rbHorizontal;
        private System.Windows.Forms.GroupBox groupBoxPlayerShips;
        private System.Windows.Forms.RadioButton rbSubmarine;
        private System.Windows.Forms.RadioButton rbPTBoat;
        private System.Windows.Forms.RadioButton rbCarrier;
        private System.Windows.Forms.RadioButton rbBattleship;
        private System.Windows.Forms.RadioButton rbCruiser;
        private System.Windows.Forms.Button btnReady;
        private System.Windows.Forms.Button btnSurrender;
        private System.Windows.Forms.Label lblTurnCounter;
        private System.Windows.Forms.Label lblCounter;
        private System.Windows.Forms.PictureBox pbHumanPTBoat;
        private System.Windows.Forms.PictureBox pbHumanCruiser;
        private System.Windows.Forms.PictureBox pbHumanSub;
        private System.Windows.Forms.PictureBox pbHumanBattleship;
        private System.Windows.Forms.PictureBox pbHumanCarrier;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.PictureBox pbCPUCarrier;
        private System.Windows.Forms.PictureBox pbCPUBattleship;
        private System.Windows.Forms.PictureBox pbCPUSub;
        private System.Windows.Forms.PictureBox pbCPUCruiser;
        private System.Windows.Forms.PictureBox pbCPUPtBoat;
        private System.Windows.Forms.Label lblHumanCoordinates;
        private System.Windows.Forms.Label lblCPUCoordinate;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.PictureBox pbHeader;

    }
}

